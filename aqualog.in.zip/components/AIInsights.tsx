
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Sparkles, Bot, User, Send, Loader } from 'lucide-react';
import { useData } from '../contexts/DataContext';

// IMPORTANT: Set your API key in environment variables
const API_KEY = process.env.API_KEY;

// Initialize AI module. It will be null if API_KEY is not set.
let ai: GoogleGenAI | null = null;
if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
} else {
  console.error("API_KEY is not set. AI features will be disabled.");
}

interface Message {
  role: 'user' | 'model';
  text: string;
}

const AIInsights: React.FC = () => {
    const { sites, ponds, waterReadings, inventory } = useData();
    const [prompt, setPrompt] = useState<string>('');
    const [chatHistory, setChatHistory] = useState<Message[]>(() => {
        try {
            const savedHistory = localStorage.getItem('aqualog-ai-chat-history');
            return savedHistory ? JSON.parse(savedHistory) : [];
        } catch (error) {
            console.error("Failed to parse chat history from localStorage", error);
            return [];
        }
    });
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        try {
            localStorage.setItem('aqualog-ai-chat-history', JSON.stringify(chatHistory));
        } catch (error) {
            console.error("Failed to save chat history to localStorage", error);
        }
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [chatHistory]);

    const generateFarmContext = useCallback(() => {
        let context = "## Farm Data Context\n\n";

        const activePonds = ponds.filter(p => p.status === 'Active');

        if (activePonds.length > 0) {
            context += "### Active Ponds Overview\n";
            activePonds.forEach(pond => {
                const daysOfCulture = Math.floor((Date.now() - new Date(pond.stockingDate).getTime()) / (1000 * 3600 * 24));
                const stockInfo = pond.stock.map(s => `${s.count} ${s.species} (Initial ABW: ${s.initialABW}g)`).join(', ');
                
                context += `\n**Pond: ${pond.name}**\n`;
                context += `- **Culture Type:** ${pond.cultureType}\n`;
                context += `- **Stock:** ${stockInfo}\n`;
                context += `- **Days of Culture (DOC):** ${daysOfCulture} days\n`;

                const latestPondReading = waterReadings
                    .filter(r => r.pondId === pond.id)
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];

                if (latestPondReading) {
                    context += `- **Latest Water Quality:** pH ${latestPondReading.pH}, DO ${latestPondReading.do}mg/L, NH₃ ${latestPondReading.nh3}ppm, NO₂ ${latestPondReading.no2}ppm\n`;
                    // Add warnings based on thresholds (these are general guidelines)
                    if (latestPondReading.nh3 && latestPondReading.nh3 > 0.1) {
                        context += `  - **WARNING:** High un-ionized ammonia (NH₃) level detected (>0.1 ppm).\n`;
                    }
                    if (latestPondReading.no2 && latestPondReading.no2 > 0.3) {
                        context += `  - **WARNING:** High nitrite (NO₂) level detected (>0.3 ppm).\n`;
                    }
                     if (latestPondReading.do && latestPondReading.do < 3) {
                        context += `  - **WARNING:** Low Dissolved Oxygen (DO) level detected (<3 mg/L).\n`;
                    }
                    if (latestPondReading.pH && (latestPondReading.pH < 6.8 || latestPondReading.pH > 8.5)) {
                        context += `  - **WARNING:** pH is outside the typical optimal range (6.8-8.5).\n`;
                    }
                } else {
                    context += `- **Latest Water Quality:** No data available.\n`;
                }
            });
        }

        const lowStockItems = inventory.filter(item => item.quantity <= item.lowStockThreshold);
        if (lowStockItems.length > 0) {
            context += "\n### Inventory Alerts\n";
            const siteName = (siteId: number) => sites.find(s => s.id === siteId)?.name || 'N/A';
            context += `- **Low Stock Items:** ${lowStockItems.map(i => `${i.name} at ${siteName(i.siteId)} (Current: ${i.quantity} ${i.unit}, Threshold: ${i.lowStockThreshold} ${i.unit})`).join('; ')}\n`;
        }

        if (context.trim() === "## Farm Data Context") {
            return "No farm data context available.";
        }
        return context;
    }, [ponds, waterReadings, inventory, sites]);


    const getAIResponse = useCallback(async (currentPrompt: string) => {
        if (!ai) {
            setChatHistory(prev => [...prev, {role: 'model', text: "AI features are disabled. API Key not configured."}]);
            return;
        }
        setIsLoading(true);
        setChatHistory(prev => [...prev, {role: 'user', text: currentPrompt}]);
        setPrompt('');

        const farmContext = generateFarmContext();
        const fullPrompt = `${farmContext}\n\n---\n\nBased on the context above, answer the following question:\n${currentPrompt}`;

        try {
            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: fullPrompt,
                config: {
                    systemInstruction: "You are an expert AI assistant for aquaculture farm management, named 'Aqua-AI'. Use the detailed, real-time farm data context provided to give specific, practical, and actionable advice. If the context is not relevant to the user's question, answer generally. Always provide concise, well-structured advice. Use markdown formatting like bullet points and bold text for clarity.",
                }
            });
            const text = response.text;
            setChatHistory(prev => [...prev, {role: 'model', text: text || "I received an empty response. Please try again."}]);
        } catch (error) {
            console.error("Error generating content:", error);
            setChatHistory(prev => [...prev, {role: 'model', text: "Sorry, I couldn't process that request. Please try again."}]);
        } finally {
            setIsLoading(false);
        }
    }, [generateFarmContext]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(prompt.trim() && !isLoading) {
            getAIResponse(prompt);
        }
    };
    
    const preCannedPrompt = (text: string) => {
        getAIResponse(text);
    }

  return (
    <div className="h-full flex flex-col">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900 flex items-center"><Sparkles className="mr-3 text-cyan-500" /> AI Insights</h1>
        <p className="text-slate-500 mt-1">Get intelligent, data-driven advice for your farm.</p>
      </header>

      <div className="bg-white rounded-xl shadow-md flex-1 flex flex-col p-2 sm:p-4">
        <div className="flex-1 overflow-y-auto space-y-4 p-2 sm:p-4">
            {chatHistory.length === 0 && (
                <div className="text-center text-slate-400 h-full flex flex-col justify-center">
                    <div>
                        <Bot size={48} className="mx-auto mb-4"/>
                        <p className="font-semibold">Ask me anything about your farm!</p>
                        <p className="text-sm mt-1">I can use your farm's data to give you tailored advice.</p>
                        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm max-w-lg mx-auto">
                            <button onClick={() => preCannedPrompt("Any warnings for Pond A1?")} className="p-3 bg-slate-100 rounded-lg hover:bg-slate-200 transition text-slate-600">Check for warnings on Pond A1</button>
                            <button onClick={() => preCannedPrompt("Based on my active ponds, suggest a feeding strategy.")} className="p-3 bg-slate-100 rounded-lg hover:bg-slate-200 transition text-slate-600">Suggest feeding strategy</button>
                            <button onClick={() => preCannedPrompt("My Probiotics stock is low. What should I do?")} className="p-3 bg-slate-100 rounded-lg hover:bg-slate-200 transition text-slate-600">Low Probiotics stock, what to do?</button>
                            <button onClick={() => preCannedPrompt("Summarize the current status of my farm.")} className="p-3 bg-slate-100 rounded-lg hover:bg-slate-200 transition text-slate-600">Summarize my farm status</button>
                        </div>
                    </div>
                </div>
            )}

            {chatHistory.map((msg, index) => (
                <div key={index} className={`flex items-start gap-2 sm:gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                    {msg.role === 'model' && <div className="flex-shrink-0 w-8 h-8 rounded-full bg-cyan-500 text-white flex items-center justify-center"><Bot size={20}/></div>}
                    <div className={`p-3 rounded-lg max-w-lg ${msg.role === 'user' ? 'bg-cyan-600 text-white' : 'bg-slate-100 text-slate-800'}`}>
                        <p className="whitespace-pre-wrap text-sm sm:text-base">{msg.text}</p>
                    </div>
                    {msg.role === 'user' && <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center"><User size={20}/></div>}
                </div>
            ))}
             {isLoading && (
                <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-cyan-500 text-white flex items-center justify-center"><Bot size={20}/></div>
                    <div className="p-3 rounded-lg bg-slate-100 text-slate-800">
                        <Loader className="animate-spin" />
                    </div>
                </div>
            )}
            <div ref={chatEndRef} />
        </div>
        
        <form onSubmit={handleSubmit} className="mt-4 border-t pt-4">
            <div className="relative">
                <input 
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder={!ai ? "AI is disabled" : "Ask for advice..."}
                    className="form-input rounded-full pr-12"
                    disabled={isLoading || !ai}
                />
                <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 bg-cyan-600 text-white p-2 rounded-full hover:bg-cyan-700 disabled:bg-slate-400" disabled={isLoading || !prompt.trim() || !ai}>
                    <Send size={20}/>
                </button>
            </div>
        </form>
      </div>
    </div>
  );
};

export default AIInsights;