
import React, { useState, useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Droplets, Fish, Layers, AlertTriangle, Sun, Globe, Wallet, Skull, ChevronRight } from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { Link } from 'react-router-dom';

const StatCard: React.FC<{ icon: React.ReactNode; title: string; value: string; color: string; }> = ({ icon, title, value, color }) => (
    <div className="bg-white p-4 rounded-xl shadow-md flex items-center space-x-4 transition-all duration-300 hover:shadow-lg hover:scale-105">
        <div className={`p-3 rounded-lg ${color}`}>
            {icon}
        </div>
        <div>
            <p className="text-sm text-slate-500">{title}</p>
            <p className="text-xl md:text-2xl font-bold text-slate-800">{value}</p>
        </div>
    </div>
);

const TabButton: React.FC<{ active: boolean; onClick: () => void; children: React.ReactNode }> = ({ active, onClick, children }) => (
    <button
        onClick={onClick}
        className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors duration-200 ${
            active ? 'bg-cyan-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-200'
        }`}
    >
        {children}
    </button>
);

const OverviewTab: React.FC = () => {
    const { sites, ponds, transactions, mortalityLogs, feedingEvents, waterReadings } = useData();
    const activeSites = sites.filter(s => !s.isDeleted).length;
    const activePonds = ponds.filter(p => p.status === 'Active').length;
    
    const { netProfit } = useMemo(() => {
        const income = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
        const expense = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
        return { netProfit: income - expense };
    }, [transactions]);

    const mortalityLast24h = useMemo(() => {
        const yesterday = Date.now() - 24 * 60 * 60 * 1000;
        return mortalityLogs
            .filter(log => new Date(log.date).getTime() > yesterday)
            .reduce((sum, log) => sum + log.mortality, 0);
    }, [mortalityLogs]);
    
    const weeklyFeedData = useMemo(() => {
        const data = new Map<string, number>();
        const today = new Date();
        for (let i = 6; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(today.getDate() - i);
            const day = date.toLocaleString('en-us', { weekday: 'short' });
            data.set(day, 0);
        }
        feedingEvents.forEach(event => {
            const eventDate = new Date(event.time);
            if (eventDate.getTime() > today.getTime() - 7 * 24 * 60 * 60 * 1000) {
                const day = eventDate.toLocaleString('en-us', { weekday: 'short' });
                data.set(day, (data.get(day) || 0) + event.quantity);
            }
        });
        return Array.from(data.entries()).map(([day, consumed]) => ({ day, consumed }));
    }, [feedingEvents]);

    const latestWaterQuality = waterReadings[0];

    return (
        <div className="space-y-6 mt-4">
             <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                <StatCard icon={<Globe className="text-white"/>} title="Active Sites" value={activeSites.toString()} color="bg-cyan-500" />
                <StatCard icon={<Droplets className="text-white"/>} title="Active Ponds" value={activePonds.toString()} color="bg-green-500" />
                <StatCard icon={<Wallet className="text-white"/>} title="Net Profit (All Time)" value={`$${netProfit.toFixed(0)}`} color="bg-blue-500" />
                <StatCard icon={<Skull className="text-white"/>} title="Mortality (24h)" value={mortalityLast24h.toString()} color="bg-red-500" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white p-4 md:p-6 rounded-xl shadow-lg">
                <h3 className="text-lg font-semibold text-slate-800 mb-4">Latest Water Quality</h3>
                {latestWaterQuality ? (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                        <div><p className="text-sm text-slate-500">Pond</p><p className="font-bold text-lg">{ponds.find(p => p.id === latestWaterQuality.pondId)?.name}</p></div>
                        <div><p className="text-sm text-slate-500">pH</p><p className="font-bold text-lg">{latestWaterQuality.pH?.toFixed(1) ?? 'N/A'}</p></div>
                        <div><p className="text-sm text-slate-500">DO</p><p className="font-bold text-lg">{latestWaterQuality.do?.toFixed(1) ?? 'N/A'} <span className="text-xs">mg/L</span></p></div>
                        <div><p className="text-sm text-slate-500">NH₃</p><p className="font-bold text-lg">{latestWaterQuality.nh3?.toFixed(2) ?? 'N/A'} <span className="text-xs">ppm</span></p></div>
                    </div>
                ) : (
                    <p className="text-slate-500">No water quality data available.</p>
                )}
                </div>
                <div className="bg-white p-4 md:p-6 rounded-xl shadow-lg">
                <h3 className="text-lg font-semibold text-slate-800 mb-4">Weekly Feed</h3>
                <ResponsiveContainer width="100%" height={150}>
                    <LineChart data={weeklyFeedData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false}/>
                        <XAxis dataKey="day" tick={{fill: '#64748b', fontSize: 12}}/>
                        <YAxis tick={{fill: '#64748b', fontSize: 12}}/>
                        <Tooltip wrapperClassName="!bg-white !border-slate-200 !rounded-md !shadow-lg"/>
                        <Legend />
                        <Line type="monotone" dataKey="consumed" stroke="#10b981" strokeWidth={2} name="Feed (Kg)" />
                    </LineChart>
                </ResponsiveContainer>
                </div>
            </div>
            <div className="bg-white p-4 md:p-6 rounded-xl shadow-lg">
                <h3 className="text-lg font-semibold text-slate-800 mb-4">Today's Tasks</h3>
                <ul className="space-y-3">
                    <li className="flex items-center space-x-3 text-sm"><span className="p-1.5 bg-green-100 text-green-700 rounded-full"><Sun size={16}/></span><span>Morning Feeding - All active ponds</span></li>
                    <li className="flex items-center space-x-3 text-sm"><span className="p-1.5 bg-blue-100 text-blue-700 rounded-full"><Droplets size={16}/></span><span>Water Quality Check - Critical Ponds</span></li>
                    <li className="flex items-center space-x-3 text-sm"><span className="p-1.5 bg-orange-100 text-orange-700 rounded-full"><Layers size={16}/></span><span>Check Feed Inventory levels</span></li>
                </ul>
            </div>
        </div>
    );
};

const PondsTab: React.FC = () => {
    const { ponds, sites } = useData();
    const getSiteName = (siteId: number) => sites.find(s => s.id === siteId)?.name || 'N/A';
    return (
        <div className="bg-white p-4 md:p-6 rounded-xl shadow-lg mt-4">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">All Ponds</h3>
            <div className="space-y-2">
                {ponds.map(pond => (
                    <Link to={`/ponds/${pond.id}`} key={pond.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-slate-50 transition-colors">
                        <div>
                            <p className="font-semibold text-slate-800">{pond.name} <span className="text-sm font-normal text-slate-500">({getSiteName(pond.siteId)})</span></p>
                            <p className="text-sm text-slate-500 truncate">{pond.stock.map(s => s.species).join(', ')}</p>
                        </div>
                        <div className="flex items-center gap-4">
                           <span className={`px-2 py-1 text-xs font-medium rounded-full ${pond.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                                {pond.status}
                            </span>
                            <ChevronRight size={18} className="text-slate-400" />
                        </div>
                    </Link>
                ))}
            </div>
        </div>
    )
}

const LowStockTab: React.FC = () => {
    const { inventory, sites } = useData();
    const getSiteName = (siteId: number) => sites.find(s => s.id === siteId)?.name || 'N/A';
    const lowStockItems = inventory.filter(item => item.quantity <= item.lowStockThreshold);
    return (
        <div className="bg-white p-4 md:p-6 rounded-xl shadow-lg mt-4">
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2"><AlertTriangle className="text-red-500" /> Low Stock Items</h3>
            <div className="space-y-2">
                {lowStockItems.length > 0 ? lowStockItems.map(item => (
                     <div key={item.id} className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                        <div>
                            <p className="font-semibold text-slate-800">{item.name} <span className="text-sm font-normal text-slate-500">({getSiteName(item.siteId)})</span></p>
                            <p className="text-sm text-red-600">
                                Current: {item.quantity} {item.unit} (Threshold: {item.lowStockThreshold} {item.unit})
                            </p>
                        </div>
                        <Link to="/inventory" className="text-sm font-medium text-cyan-600 hover:underline">Manage</Link>
                    </div>
                )) : <p className="text-slate-500 text-center py-4">No items are low on stock. Great job!</p>}
            </div>
        </div>
    )
}

const FinancialsTab: React.FC = () => {
    const { transactions } = useData();
    const { totalIncome, totalExpense, netProfit } = useMemo(() => {
        const income = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
        const expense = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
        return { totalIncome: income, totalExpense: expense, netProfit: income - expense };
    }, [transactions]);
    return (
         <div className="bg-white p-4 md:p-6 rounded-xl shadow-lg mt-4">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">Financial Summary (All Time)</h3>
            <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                    <p className="font-medium text-green-800">Total Income</p>
                    <p className="font-bold text-lg text-green-600">${totalIncome.toFixed(2)}</p>
                </div>
                 <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                    <p className="font-medium text-red-800">Total Expenses</p>
                    <p className="font-bold text-lg text-red-600">${totalExpense.toFixed(2)}</p>
                </div>
                 <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg border-t-2 border-blue-200">
                    <p className="font-medium text-blue-800">Net Profit</p>
                    <p className="font-bold text-lg text-blue-600">${netProfit.toFixed(2)}</p>
                </div>
            </div>
        </div>
    );
}

const Dashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'ponds' | 'lowStock' | 'financials'>('overview');

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-slate-500 mt-1">Welcome back! Here's what's happening on your farm.</p>
      </header>

      <div className="flex space-x-2 border-b border-slate-200">
        <TabButton active={activeTab === 'overview'} onClick={() => setActiveTab('overview')}>Overview</TabButton>
        <TabButton active={activeTab === 'ponds'} onClick={() => setActiveTab('ponds')}>Ponds</TabButton>
        <TabButton active={activeTab === 'lowStock'} onClick={() => setActiveTab('lowStock')}>Low Stock</TabButton>
        <TabButton active={activeTab === 'financials'} onClick={() => setActiveTab('financials')}>Financials</TabButton>
      </div>

      <div>
        {activeTab === 'overview' && <OverviewTab />}
        {activeTab === 'ponds' && <PondsTab />}
        {activeTab === 'lowStock' && <LowStockTab />}
        {activeTab === 'financials' && <FinancialsTab />}
      </div>
    </div>
  );
};

export default Dashboard;
