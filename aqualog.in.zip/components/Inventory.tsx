import React from 'react';

// This component is obsolete. Its functionality has been moved into Sites.tsx
const Inventory: React.FC = () => {
  return null;
};

export default Inventory;