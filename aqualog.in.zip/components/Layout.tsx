
import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation, useNavigate, Navigate } from 'react-router-dom';
import { LayoutDashboard, Fish, MessageCircle, Settings as CogIcon, Globe, Users, LogOut, Menu, X, BarChart3, TestTube2 } from 'lucide-react';

import Dashboard from './Dashboard';
import AIInsights from './AIInsights';
import Sites from './Sites';
import PondDetail from './PondDetail';
import WaterQuality from './WaterQuality';
import Reports from './Reports';
import Supervisors from './Supervisors';
import Settings from './Settings';
import { useAuth } from '../contexts/AuthContext';

const NavLink: React.FC<{ to: string; icon: React.ReactNode; children: React.ReactNode; onClick?: () => void; }> = ({ to, icon, children, onClick }) => {
  const location = useLocation();
  const isActive = location.pathname.startsWith(to) && to !== '/';
  const isDashboardActive = location.pathname === '/';

  return (
    <Link to={to} onClick={onClick} className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 ${ (to === '/' && isDashboardActive) || (to !== '/' && isActive) ? 'bg-cyan-600 text-white shadow-md' : 'text-cyan-100 hover:bg-cyan-700/50 hover:text-white'}`}>
      {icon}
      <span className="ml-3">{children}</span>
    </Link>
  );
};

const Layout: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false); // Hidden by default on mobile
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Close sidebar on navigation in mobile view
    setIsSidebarOpen(false);
  }, [location.pathname]);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const SidebarContent = ({ onLinkClick }: { onLinkClick?: () => void }) => (
    <>
      <div className="flex items-center justify-between p-4 border-b border-cyan-700">
        <h1 className="text-xl font-bold">AquaLog.in</h1>
      </div>
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        <p className="px-4 pt-4 pb-2 text-xs font-semibold text-cyan-300 uppercase">Menu</p>
        <NavLink to="/" icon={<LayoutDashboard size={20} />} onClick={onLinkClick}>Dashboard</NavLink>
        <NavLink to="/sites" icon={<Globe size={20} />} onClick={onLinkClick}>Sites</NavLink>
        
        <p className="px-4 pt-4 pb-2 text-xs font-semibold text-cyan-300 uppercase">Management</p>
        <NavLink to="/reports" icon={<BarChart3 size={20} />} onClick={onLinkClick}>Reports</NavLink>
        {user?.role === 'admin' && <NavLink to="/supervisors" icon={<Users size={20} />} onClick={onLinkClick}>Supervisors</NavLink>}

        <p className="px-4 pt-4 pb-2 text-xs font-semibold text-cyan-300 uppercase">Tools</p>
        <NavLink to="/ai-insights" icon={<MessageCircle size={20} />} onClick={onLinkClick}>AI Insights</NavLink>
        <NavLink to="/settings" icon={<CogIcon size={20} />} onClick={onLinkClick}>Settings</NavLink>
      </nav>
      <div className="p-4 border-t border-cyan-700">
         <button onClick={handleLogout} className="flex items-center w-full px-4 py-3 text-sm font-medium text-cyan-100 rounded-lg hover:bg-cyan-700/50 hover:text-white">
            <LogOut size={20} />
            <span className="ml-3">Logout</span>
         </button>
      </div>
    </>
  );

  return (
      <div className="flex h-screen bg-slate-100">
        {/* Mobile Sidebar */}
        <aside className={`fixed inset-y-0 left-0 z-40 bg-cyan-800 text-white w-64 transform transition-transform duration-300 ease-in-out md:hidden ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <SidebarContent onLinkClick={() => setIsSidebarOpen(false)} />
        </aside>
        {isSidebarOpen && <div className="fixed inset-0 bg-black opacity-50 z-30 md:hidden" onClick={() => setIsSidebarOpen(false)}></div>}

        {/* Desktop Sidebar */}
        <aside className="hidden md:flex md:w-64 bg-cyan-800 text-white flex-col">
          <SidebarContent />
        </aside>

        <div className="flex-1 flex flex-col">
          <header className="md:hidden bg-white shadow-md z-20">
            <div className="flex items-center justify-between p-4">
              <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 text-slate-600">
                <Menu size={24} />
              </button>
              <h1 className="text-lg font-bold text-cyan-800">AquaLog.in</h1>
              <div className="w-8"></div>
            </div>
          </header>
          
          <main className="flex-1 overflow-y-auto p-4 md:p-8 bg-slate-50">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/sites" element={<Sites />} />
              <Route path="/ponds/:pondId" element={<PondDetail />} />
              <Route path="/reports" element={<Reports />} />
              {user?.role === 'admin' && <Route path="/supervisors" element={<Supervisors />} />}
              <Route path="/ai-insights" element={<AIInsights />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </main>
        </div>
      </div>
  );
};

export default Layout;
