
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Fish } from 'lucide-react';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const user = login(email);
    if (user) {
      navigate('/');
    } else {
      setError('User not found. Please use a valid email.');
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-cyan-800">
      <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-2xl shadow-xl">
        <div className="text-center">
            <Fish className="mx-auto h-12 w-auto text-cyan-600"/>
          <h2 className="mt-6 text-3xl font-bold text-gray-900">
            Welcome to AquaLog.in
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Sign in to manage your farm
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-1 rounded-md shadow-sm">
            <div>
              <label htmlFor="email-address" className="sr-only">
                Email address
              </label>
              <input
                id="email-address"
                name="email"
                type="email"
                autoComplete="email"
                required
                className="form-input"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          {error && <p className="text-sm text-red-600">{error}</p>}

          <div>
            <button
              type="submit"
              className="relative flex justify-center w-full px-4 py-3 text-sm font-medium text-white bg-cyan-600 border border-transparent rounded-md group hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500"
            >
              Sign in
            </button>
          </div>
        </form>
         <div className="p-4 mt-4 text-sm text-center bg-slate-100 rounded-lg">
            <h4 className="font-semibold">Demo Accounts</h4>
            <ul className="mt-2 text-slate-600">
                <li><span className="font-medium">Admin:</span> admin@aqualog.in</li>
                <li><span className="font-medium">Supervisor:</span> supervisor@aqualog.in</li>
                <li><span className="font-medium">Farmer:</span> farmer@aqualog.in</li>
            </ul>
        </div>
      </div>
    </div>
  );
};

export default Login;
