
import React, { useState, useMemo, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useData } from '../contexts/DataContext';
import { useAuth } from '../contexts/AuthContext';
import { ArrowLeft, Droplets, Fish, Thermometer, Skull, Weight, Beaker, Calendar, Star, Package, User, Plus, X, Anchor, List, LayoutGrid, Trash2, Info, PlusCircle } from 'lucide-react';
import Modal from './Modal';
import type { Pond, PondEvent, FeedingEvent, InventoryItem, CultureType, WaterQualityReading, ABWLog, MortalityLog, HarvestType, HarvestLog, ApplicationLog } from '../types';
import { mockUsers } from '../data/mockData';
import { CULTURE_FEEDING_SLOTS, CULTURE_SPECIES_MAP } from '../data/aquacultureData';

type RangeKey = keyof Omit<WaterQualityReading, 'id' | 'pondId' | 'date' | 'recordedById' | 'remarks'>;

const RANGES: { [key in RangeKey]?: { min?: number, max?: number, label: string } } = {
  pH: { min: 7.5, max: 8.5, label: 'pH' },
  salinity: { min: 0, max: 30, label: 'Salinity (ppt)' },
  alkalinity: { min: 100, max: 300, label: 'Alkalinity (mg/L)' },
  co3: { min: 0, max: 32, label: 'CO₃ (mg/L)' },
  hco3: { min: 100, max: 300, label: 'HCO₃ (mg/L)' },
  hardness: { label: 'Hardness (mg/L)' },
  ammonia_total: { max: 1.0, label: 'Total Ammonia (ppm)' },
  nh3: { max: 0.1, label: 'NH₃ (ppm)' },
  no2: { max: 0.3, label: 'NO₂ (ppm)' },
  no3: { max: 10, label: 'NO₃ (ppm)' },
  h2s: { max: 0.2, label: 'H₂S (ppm)' },
  co2: { max: 15, label: 'CO₂ (ppm)' },
  do: { min: 3, max: 5, label: 'DO (mg/L)' },
};

const chemicalFields: RangeKey[] = ['pH', 'salinity', 'alkalinity', 'co3', 'hco3', 'hardness'];
const gasFields: RangeKey[] = ['do', 'ammonia_total', 'nh3', 'no2', 'no3', 'h2s', 'co2'];

const StatCard: React.FC<{ label: string; value: React.ReactNode; icon: React.ReactNode; }> = ({ label, value, icon }) => (
    <div className="bg-slate-100 p-4 rounded-lg flex items-center gap-4">
        <div className="bg-white p-2 rounded-full shadow-sm">{icon}</div>
        <div>
            <p className="text-sm text-slate-500">{label}</p>
            <p className="font-bold text-slate-800 text-lg">{value}</p>
        </div>
    </div>
);

const HistoryTabButton: React.FC<{ active: boolean, onClick: () => void, children: React.ReactNode }> = ({ active, onClick, children }) => (
    <button onClick={onClick} className={`px-4 py-3 text-sm font-medium border-b-2 flex items-center gap-2 ${active ? 'border-cyan-600 text-cyan-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>
        {children}
    </button>
);

const UnifiedEventCard: React.FC<{ event: PondEvent }> = ({ event }) => {
    const renderDetails = () => {
        switch (event.type) {
            case 'feed':
                 const { inventory: feedInventory } = useData();
                 const feedItemName = feedInventory.find(i => i.id === event.inventoryFeedId)?.name || 'Unknown Item';
                 const supplementsText = event.supplements.map(s => `${s.quantityUsed.toFixed(2)} ${feedInventory.find(i => i.id === s.inventoryItemId)?.unit || 'units'} ${feedInventory.find(i => i.id === s.inventoryItemId)?.name || 'Unknown Item'}`).join(', ');
                return (
                    <div>
                        <p>Slot {event.feedSlot}: Fed <span className="font-bold">{event.quantity}kg</span> of {feedItemName}.</p>
                        {supplementsText && <p className="text-xs text-slate-500 mt-1">Supplements: {supplementsText}</p>}
                    </div>
                );
            case 'water': return <p>Water Reading: pH: {event.pH}, DO: {event.do}mg/L, NH₃: {event.nh3}ppm, NO₂: {event.no2}ppm</p>;
            case 'mortality': return <p><span className="font-bold text-red-600">{event.mortality} mortalities</span> recorded for {event.speciesName}. Remaining: {event.newStock.toLocaleString()}.</p>;
            case 'harvest': return <p>({event.harvestType}) Harvested <span className="font-bold">{event.numberHarvested.toLocaleString()}</span> {event.speciesName} ({event.totalWeight.toLocaleString()}kg) with ABW of <span className="font-bold">{(event.abw * 1000).toFixed(1)}g</span>.</p>;
            case 'abw': return <p>ABW for {event.speciesName}: <span className="font-bold">{event.calculatedAbw.toFixed(1)}g</span>. FCR: {event.fcrThisPeriod?.toFixed(2) ?? 'N/A'}.</p>;
            case 'application': return <p>Applied <span className="font-bold">{event.quantityUsed} {event.unit}</span> of {event.productName} for: <span className="italic">{event.purpose || "general use"}</span>.</p>;
            default: return null;
        }
    }
    const icon = {
        feed: <Fish size={18} className="text-orange-500" />,
        water: <Droplets size={18} className="text-blue-500" />,
        mortality: <Skull size={18} className="text-red-500" />,
        harvest: <Anchor size={18} className="text-green-500" />,
        abw: <Weight size={18} className="text-purple-500" />,
        application: <Beaker size={18} className="text-indigo-500" />,
    }[event.type];
    
    let eventDate;
    switch(event.type) {
        case 'feed': eventDate = event.time; break;
        case 'water': eventDate = event.date; break;
        case 'mortality': eventDate = event.date; break;
        case 'harvest': eventDate = event.date; break;
        case 'abw': eventDate = event.samplingDate; break;
        case 'application': eventDate = event.date; break;
        default: eventDate = new Date().toISOString();
    }

    return (
        <div className="flex gap-4">
            <div className="flex flex-col items-center">
                <div className="bg-white rounded-full p-2 border shadow-sm">{icon}</div>
                <div className="flex-1 w-px bg-slate-300 my-2"></div>
            </div>
            <div>
                <p className="text-xs text-slate-500 -mt-1 mb-1">{new Date(eventDate).toLocaleString()}</p>
                <div className="text-sm text-slate-700">{renderDetails()}</div>
            </div>
        </div>
    )
}

type ModalType = 'mortality'|'abw'|'application'|'feed'|'harvest'|'water';

interface SlotData {
  inventoryFeedId?: number;
  quantity: number;
  supplements: { inventoryItemId: number; quantityUsed: number }[];
}

const getCultureSpeciesGroups = (pond: Pond): { type: CultureType; species: string[] }[] => {
    const groups: Record<string, { species: string[], type: CultureType }> = {};
    const shrimpSpecies = CULTURE_SPECIES_MAP['🦐 Shrimp'];
    const fishSpecies = CULTURE_SPECIES_MAP['🐟 Fresh Water Fish'];
    const marineSpecies = CULTURE_SPECIES_MAP['🌊 Marine Fish'];

    pond.stock.forEach(stockItem => {
        if (shrimpSpecies.includes(stockItem.species)) {
            if (!groups.Shrimp) groups.Shrimp = { species: [], type: '🦐 Shrimp' };
            groups.Shrimp.species.push(stockItem.species);
        } else if (fishSpecies.includes(stockItem.species)) {
            if (!groups.Fish) groups.Fish = { species: [], type: '🐟 Fresh Water Fish' };
            groups.Fish.species.push(stockItem.species);
        } else if (marineSpecies.includes(stockItem.species)) {
            if (!groups.Marine) groups.Marine = { species: [], type: '🌊 Marine Fish' };
            groups.Marine.species.push(stockItem.species);
        }
    });
    return Object.values(groups);
};

const PondDetail: React.FC = () => {
    const { pondId } = useParams();
    const { 
        sites, ponds, abwLogs, waterReadings, getAllEventsForPond,
    } = useData();
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [modalType, setModalType] = useState<ModalType|null>(null);
    const [activeHistoryTab, setActiveHistoryTab] = useState('overview');

    const [feedDate, setFeedDate] = useState(new Date().toISOString().split('T')[0]);
    const [slotData, setSlotData] = useState<Record<string, SlotData>>({});


    const pond = useMemo(() => ponds.find(p => p.id === Number(pondId)), [ponds, pondId]);
    
    useEffect(() => {
        if (!isModalOpen || modalType !== 'feed') return;
        setSlotData({});
        setFeedDate(new Date().toISOString().split('T')[0]);
    }, [isModalOpen, modalType]);


    const site = useMemo(() => sites.find(s => s.id === pond?.siteId), [sites, pond]);
    const events = useMemo(() => pond ? getAllEventsForPond(pond.id) : [], [pond, getAllEventsForPond]);
    
    const daysOfCulture = useMemo(() => {
        if (!pond) return 0;
        return Math.floor((Date.now() - new Date(pond.stockingDate).getTime()) / (1000 * 3600 * 24));
    }, [pond]);

    const lastABW = useMemo(() => abwLogs.filter(l => l.pondId === pond?.id).sort((a,b) => new Date(b.samplingDate).getTime() - new Date(a.samplingDate).getTime())[0], [abwLogs, pond]);
    const lastWaterReading = useMemo(() => waterReadings.filter(l => l.pondId === pond?.id).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0], [waterReadings, pond]);
    
    const openModal = (type: ModalType) => {
        setModalType(type);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setModalType(null);
    };

    const { addFeedingEvent } = useData();
    const { user } = useAuth();
    
    const handleSaveFeed = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        if (!pond || !user) return;

        const datePart = feedDate;
        const timePart = new Date().toTimeString().split(' ')[0];
        const timestamp = new Date(`${datePart}T${timePart}`).toISOString();

        Object.keys(slotData).forEach(key => {
            const data = slotData[key];

            if (data && data.inventoryFeedId && data.quantity > 0) {
                 const newEvent: Omit<FeedingEvent, 'id'> = {
                    pondId: pond.id,
                    feedSlot: parseInt(key.split('-').pop()!) + 1, // key is 'speciesGroup-slotIndex'
                    inventoryFeedId: data.inventoryFeedId,
                    quantity: data.quantity,
                    supplements: data.supplements.filter(s => s.inventoryItemId && s.quantityUsed > 0),
                    time: timestamp,
                    recordedById: user.id
                };
                addFeedingEvent(newEvent);
            }
        });

        closeModal();
    };
    
    const { addWaterReading } = useData();
    const handleSaveWaterQuality = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const form = e.target as HTMLFormElement;
        const formData = new FormData(form);
        if (!pond || !user) return;

        const getFormValue = (key: string): string | undefined => {
            const val = formData.get(key);
            return val === null ? undefined : String(val);
        };
        
        const getNumericFormValue = (key: string): number | undefined => {
            const val = getFormValue(key);
            return val ? parseFloat(val) : undefined;
        }

        const readingData: Omit<WaterQualityReading, 'id'> = {
            pondId: pond.id,
            date: getFormValue('date') || new Date().toISOString().split('T')[0],
            recordedById: user.id,
            remarks: getFormValue('remarks'),
            pH: getNumericFormValue('pH'),
            salinity: getNumericFormValue('salinity'),
            alkalinity: getNumericFormValue('alkalinity'),
            co3: getNumericFormValue('co3'),
            hco3: getNumericFormValue('hco3'),
            hardness: getNumericFormValue('hardness'),
            ammonia_total: getNumericFormValue('ammonia_total'),
            nh3: getNumericFormValue('nh3'),
            no2: getNumericFormValue('no2'),
            no3: getNumericFormValue('no3'),
            h2s: getNumericFormValue('h2s'),
            co2: getNumericFormValue('co2'),
            do: getNumericFormValue('do'),
        };
        
        addWaterReading(readingData);
        closeModal();
    };
    
    if (!pond || !site) {
        return <div className="p-8 text-center">Loading pond details or pond not found...</div>;
    }
    
    const speciesText = pond.stock.map(s => `${s.species} (${s.count.toLocaleString()})`).join(', ');

    return (
        <div className="space-y-6">
            <header>
                <Link to="/sites" className="flex items-center text-sm text-cyan-600 hover:underline mb-2">
                    <ArrowLeft size={16} className="mr-1"/> Back to Sites
                </Link>
                <h1 className="text-2xl md:text-3xl font-bold text-slate-900">{pond.name}</h1>
                <p className="text-slate-500 mt-1">Details and history for this pond at <span className="font-semibold">{site.name}</span>.</p>
            </header>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard label="Days of Culture" value={`${daysOfCulture} days`} icon={<Calendar size={20} className="text-cyan-500"/>}/>
                <StatCard label="Species & Stock" value={speciesText} icon={<Fish size={20} className="text-green-500"/>}/>
                <StatCard label="Last Recorded ABW" value={lastABW ? `${lastABW.calculatedAbw.toFixed(1)} g` : 'N/A'} icon={<Weight size={20} className="text-purple-500"/>}/>
                <StatCard label="Last Water DO" value={lastWaterReading ? `${lastWaterReading.do?.toFixed(1)} mg/L` : 'N/A'} icon={<Droplets size={20} className="text-blue-500"/>}/>
            </div>

            <div className="bg-white p-4 rounded-xl shadow-md">
                <h3 className="text-lg font-semibold text-slate-800 mb-4">Quick Actions</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                    <button onClick={() => openModal('feed')} className="quick-action-btn bg-orange-100 text-orange-700"><Fish size={20}/>Log Feed</button>
                    <button onClick={() => openModal('water')} className="quick-action-btn bg-blue-100 text-blue-700"><Droplets size={20}/>Log Water</button>
                    <button onClick={() => openModal('mortality')} className="quick-action-btn bg-red-100 text-red-700"><Skull size={20}/>Log Mortality</button>
                    <button onClick={() => openModal('abw')} className="quick-action-btn bg-purple-100 text-purple-700"><Weight size={20}/>Log ABW</button>
                    <button onClick={() => openModal('application')} className="quick-action-btn bg-indigo-100 text-indigo-700"><Beaker size={20}/>Log Application</button>
                    <button onClick={() => openModal('harvest')} className="quick-action-btn bg-green-100 text-green-700"><Anchor size={20}/>Log Harvest</button>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-md">
                <div className="border-b border-slate-200 flex overflow-x-auto">
                    <HistoryTabButton active={activeHistoryTab === 'overview'} onClick={() => setActiveHistoryTab('overview')}><Star size={16}/>Overview</HistoryTabButton>
                    <HistoryTabButton active={activeHistoryTab === 'water'} onClick={() => setActiveHistoryTab('water')}><Droplets size={16}/>Water Quality</HistoryTabButton>
                    <HistoryTabButton active={activeHistoryTab === 'feed'} onClick={() => setActiveHistoryTab('feed')}><Fish size={16}/>Feed</HistoryTabButton>
                    <HistoryTabButton active={activeHistoryTab === 'mortality'} onClick={() => setActiveHistoryTab('mortality')}><Skull size={16}/>Mortality</HistoryTabButton>
                    <HistoryTabButton active={activeHistoryTab === 'harvest'} onClick={() => setActiveHistoryTab('harvest')}><Anchor size={16}/>Harvest</HistoryTabButton>
                    <HistoryTabButton active={activeHistoryTab === 'abw'} onClick={() => setActiveHistoryTab('abw')}><Weight size={16}/>ABW Log</HistoryTabButton>
                    <HistoryTabButton active={activeHistoryTab === 'application'} onClick={() => setActiveHistoryTab('application')}><Beaker size={16}/>Applications</HistoryTabButton>
                </div>
                <div className="p-4 max-h-[60vh] overflow-y-auto">
                    {activeHistoryTab === 'overview' && <div className="space-y-4">{events.map(event => <UnifiedEventCard key={`${event.type}-${event.id}`} event={event} />)}</div>}
                    {activeHistoryTab === 'water' && <WaterQualityHistoryTab pond={pond} />}
                    {activeHistoryTab === 'feed' && <FeedHistoryTab pond={pond} />}
                    {activeHistoryTab === 'mortality' && <MortalityHistoryTab pond={pond} />}
                    {activeHistoryTab === 'harvest' && <HarvestHistoryTab pond={pond} />}
                    {activeHistoryTab === 'abw' && <ABWHistoryTab pond={pond} />}
                    {activeHistoryTab === 'application' && <ApplicationHistoryTab pond={pond} />}
                </div>
            </div>

             {isModalOpen && (
                <Modal isOpen={isModalOpen} onClose={closeModal} title={`Log ${modalType?.charAt(0).toUpperCase() + modalType!.slice(1)}`}>
                    {modalType === 'mortality' && <MortalityForm pond={pond} onCancel={closeModal} />}
                    {modalType === 'abw' && <ABWForm pond={pond} onCancel={closeModal} />}
                    {modalType === 'application' && <ApplicationForm pond={pond} onCancel={closeModal} />}
                    {modalType === 'feed' && <FeedForm pond={pond} feedDate={feedDate} setFeedDate={setFeedDate} slotData={slotData} setSlotData={setSlotData} onSubmit={handleSaveFeed} onCancel={closeModal} />}
                    {modalType === 'harvest' && <HarvestForm pond={pond} onCancel={closeModal} />}
                    {modalType === 'water' && <WaterQualityForm pond={pond} onSubmit={handleSaveWaterQuality} onCancel={closeModal} />}
                </Modal>
            )}

            <style>{`
                .quick-action-btn { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 0.5rem; padding: 1rem 0.5rem; border-radius: 0.5rem; font-size: 0.875rem; font-weight: 500; text-align: center; transition: all 0.2s; }
                .quick-action-btn:hover { transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
            `}</style>
        </div>
    );
};

const WaterQualityHistoryTab: React.FC<{ pond: Pond }> = ({ pond }) => {
    const { waterReadings, deleteWaterReading } = useData();
    const pondLogs = useMemo(() => waterReadings.filter(r => r.pondId === pond.id), [waterReadings, pond.id]);
    
    const handleDelete = (id: number) => {
        if(window.confirm('Are you sure you want to delete this water quality log?')) {
            deleteWaterReading(id);
        }
    }

    return (
        <div className="overflow-x-auto">
            <table className="w-full text-sm">
                <thead className="bg-slate-50"><tr><th className="th-cell">Date</th><th className="th-cell">pH</th><th className="th-cell">Salinity</th><th className="th-cell">DO</th><th className="th-cell">NH₃</th><th className="th-cell">NO₂</th><th className="th-cell">Remarks</th><th className="th-cell"></th></tr></thead>
                <tbody>{pondLogs.map(log => (<tr key={log.id} className="tr-cell">
                    <td className="td-cell">{new Date(log.date).toLocaleDateString()}</td>
                    <td className="td-cell">{log.pH?.toFixed(1) ?? 'N/A'}</td>
                    <td className="td-cell">{log.salinity?.toFixed(1) ?? 'N/A'}</td>
                    <td className="td-cell">{log.do?.toFixed(1) ?? 'N/A'}</td>
                    <td className="td-cell">{log.nh3?.toFixed(2) ?? 'N/A'}</td>
                    <td className="td-cell">{log.no2?.toFixed(2) ?? 'N/A'}</td>
                    <td className="td-cell truncate max-w-xs">{log.remarks || '-'}</td>
                    <td className="td-cell"><button onClick={() => handleDelete(log.id)} className="p-1 text-slate-400 hover:text-red-500"><Trash2 size={16}/></button></td>
                </tr>))}</tbody>
            </table>
             {pondLogs.length === 0 && <p className="text-center text-slate-500 py-6">No water quality logs for this pond.</p>}
            <style>{`.th-cell{padding:8px 12px; text-align:left; font-weight:600; color:#475569;} .tr-cell:hover{background-color:#f8fafc;} .td-cell{padding:8px 12px; border-top:1px solid #e2e8f0; color:#334155;}`}</style>
        </div>
    );
};

const FeedHistoryTab: React.FC<{ pond: Pond }> = ({ pond }) => {
    const { feedingEvents, inventory, deleteFeedingEvent } = useData();
    const [view, setView] = useState<'detailed'|'summary'>('detailed');
    const pondEvents = useMemo(() => feedingEvents.filter(e => e.pondId === pond.id), [feedingEvents, pond.id]);

    const dailySummary = useMemo(() => {
        const summary: Record<string, { total: number, accumulated: number, slots: Record<number, number> }> = {};
        let runningTotal = 0;
        const sortedEvents = [...pondEvents].sort((a,b) => new Date(a.time).getTime() - new Date(b.time).getTime());

        sortedEvents.forEach(event => {
            const date = new Date(event.time).toISOString().split('T')[0];
            if (!summary[date]) {
                summary[date] = { total: 0, accumulated: 0, slots: {} };
            }
            summary[date].total += event.quantity;
            if (!summary[date].slots[event.feedSlot]) summary[date].slots[event.feedSlot] = 0;
            summary[date].slots[event.feedSlot] += event.quantity;
        });
        
        const sortedDates = Object.keys(summary).sort((a,b) => new Date(a).getTime() - new Date(b).getTime());
        sortedDates.forEach(date => {
            runningTotal += summary[date].total;
            summary[date].accumulated = runningTotal;
        });

        return sortedDates.reverse().map(date => ({ date, ...summary[date] }));
    }, [pondEvents]);

    const cultureSlots = CULTURE_FEEDING_SLOTS[pond.cultureType] || CULTURE_FEEDING_SLOTS['🌀 Mixed / Polyculture'];

    return (
        <div>
            <div className="flex justify-end mb-4">
                <button onClick={() => setView('detailed')} className={`px-3 py-1 text-sm rounded-l-md ${view === 'detailed' ? 'bg-cyan-600 text-white' : 'bg-slate-200'}`}><List size={16}/></button>
                <button onClick={() => setView('summary')} className={`px-3 py-1 text-sm rounded-r-md ${view === 'summary' ? 'bg-cyan-600 text-white' : 'bg-slate-200'}`}><LayoutGrid size={16}/></button>
            </div>
            <div className="overflow-x-auto">
                {view === 'detailed' ? (
                     <table className="w-full text-sm">
                        <thead className="bg-slate-50"><tr><th className="th-cell">Date</th><th className="th-cell">Slot</th><th className="th-cell">Feed Item</th><th className="th-cell">Qty (kg)</th><th className="th-cell">Supplements</th><th className="th-cell"></th></tr></thead>
                        <tbody>{pondEvents.map(e => {
                            const feedItem = inventory.find(i => i.id === e.inventoryFeedId);
                            const supplementsText = e.supplements.map(s => inventory.find(i=>i.id === s.inventoryItemId)?.name).join(', ') || 'None';
                            return (<tr key={e.id} className="tr-cell">
                                <td className="td-cell">{new Date(e.time).toLocaleString()}</td>
                                <td className="td-cell">{e.feedSlot}</td>
                                <td className="td-cell">{feedItem?.name}</td>
                                <td className="td-cell">{e.quantity.toFixed(2)}</td>
                                <td className="td-cell">{supplementsText}</td>
                                <td className="td-cell"><button onClick={() => deleteFeedingEvent(e.id)} className="p-1 text-slate-400 hover:text-red-500"><Trash2 size={16}/></button></td>
                            </tr>)
                        })}</tbody>
                    </table>
                ) : (
                    <table className="w-full text-sm">
                        <thead className="bg-slate-50">
                            <tr>
                                <th className="th-cell">Date</th>
                                {cultureSlots.labels.map(label => <th key={label} className="th-cell">{label}</th>)}
                                <th className="th-cell">Total</th><th className="th-cell">Accumulated</th>
                            </tr>
                        </thead>
                         <tbody>{dailySummary.map(row => (
                             <tr key={row.date} className="tr-cell">
                                 <td className="td-cell">{new Date(row.date).toLocaleDateString()}</td>
                                 {cultureSlots.labels.map((_, i) => <td key={i} className="td-cell">{(row.slots[i+1] || 0).toFixed(2)}</td>)}
                                 <td className="td-cell font-bold">{row.total.toFixed(2)}</td>
                                 <td className="td-cell">{row.accumulated.toFixed(2)}</td>
                             </tr>
                         ))}</tbody>
                    </table>
                )}
            </div>
             <style>{`.th-cell{padding:8px 12px; text-align:left; font-weight:600; color:#475569;} .tr-cell:hover{background-color:#f8fafc;} .td-cell{padding:8px 12px; border-top:1px solid #e2e8f0; color:#334155;}`}</style>
        </div>
    );
}

const MortalityHistoryTab: React.FC<{ pond: Pond }> = ({ pond }) => {
    const { mortalityLogs, deleteMortalityLog } = useData();
    const pondLogs = useMemo(() => mortalityLogs.filter(r => r.pondId === pond.id), [mortalityLogs, pond.id]);
    const getUserName = (id?: number) => mockUsers.find(u => u.id === id)?.name || 'N/A';
    return (
        <div className="overflow-x-auto">
            <table className="w-full text-sm">
                <thead className="bg-slate-50"><tr><th className="th-cell">Date</th><th className="th-cell">Species</th><th className="th-cell">Mortality</th><th className="th-cell">Remaining Stock</th><th className="th-cell">Recorded By</th><th className="th-cell"></th></tr></thead>
                <tbody>{pondLogs.map(l => (<tr key={l.id} className="tr-cell">
                    <td className="td-cell">{new Date(l.date).toLocaleDateString()}</td>
                    <td className="td-cell">{l.speciesName}</td>
                    <td className="td-cell font-bold text-red-600">{l.mortality.toLocaleString()}</td>
                    <td className="td-cell">{l.newStock.toLocaleString()}</td>
                    <td className="td-cell">{getUserName(l.recordedById)}</td>
                    <td className="td-cell"><button onClick={() => deleteMortalityLog(l.id)} className="p-1 text-slate-400 hover:text-red-500"><Trash2 size={16}/></button></td>
                </tr>))}</tbody>
            </table>
            {pondLogs.length === 0 && <p className="text-center text-slate-500 py-6">No mortality logs for this pond.</p>}
            <style>{`.th-cell{padding:8px 12px; text-align:left; font-weight:600; color:#475569;} .tr-cell:hover{background-color:#f8fafc;} .td-cell{padding:8px 12px; border-top:1px solid #e2e8f0; color:#334155;}`}</style>
        </div>
    );
}

const HarvestHistoryTab: React.FC<{ pond: Pond }> = ({ pond }) => {
    const { harvestLogs, deleteHarvestLog } = useData();
    const pondLogs = useMemo(() => harvestLogs.filter(r => r.pondId === pond.id), [harvestLogs, pond.id]);
    const getUserName = (id?: number) => mockUsers.find(u => u.id === id)?.name || 'N/A';
    return (
        <div className="overflow-x-auto">
            <table className="w-full text-sm">
                <thead className="bg-slate-50">
                    <tr>
                        <th className="th-cell">Date</th>
                        <th className="th-cell">Species</th>
                        <th className="th-cell">Type</th>
                        <th className="th-cell">No. Harvested</th>
                        <th className="th-cell">Weight (kg)</th>
                        <th className="th-cell">ABW (g)</th>
                        <th className="th-cell">Value</th>
                        <th className="th-cell">Recorded By</th>
                        <th className="th-cell"></th>
                    </tr>
                </thead>
                <tbody>{pondLogs.map(l => (<tr key={l.id} className="tr-cell">
                    <td className="td-cell">{new Date(l.date).toLocaleDateString()}</td>
                    <td className="td-cell">{l.speciesName}</td>
                    <td className="td-cell"><span className={`px-2 py-1 text-xs font-medium rounded-full ${l.harvestType === 'Full' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'}`}>{l.harvestType}</span></td>
                    <td className="td-cell">{l.numberHarvested.toLocaleString()}</td>
                    <td className="td-cell">{l.totalWeight.toLocaleString()}</td>
                    <td className="td-cell font-bold">{(l.abw * 1000).toFixed(1)}</td>
                    <td className="td-cell">{l.value ? `$${l.value.toLocaleString()}` : 'N/A'}</td>
                    <td className="td-cell">{getUserName(l.recordedById)}</td>
                    <td className="td-cell"><button onClick={() => deleteHarvestLog(l.id)} className="p-1 text-slate-400 hover:text-red-500"><Trash2 size={16}/></button></td>
                </tr>))}</tbody>
            </table>
            {pondLogs.length === 0 && <p className="text-center text-slate-500 py-6">No harvest logs for this pond.</p>}
            <style>{`.th-cell{padding:8px 12px; text-align:left; font-weight:600; color:#475569;} .tr-cell:hover{background-color:#f8fafc;} .td-cell{padding:8px 12px; border-top:1px solid #e2e8f0; color:#334155;}`}</style>
        </div>
    );
};

const ABWHistoryTab: React.FC<{ pond: Pond }> = ({ pond }) => {
    const { abwLogs, deleteABWLog } = useData();
    const pondLogs = useMemo(() => abwLogs
        .filter(r => r.pondId === pond.id)
        .sort((a,b) => new Date(b.samplingDate).getTime() - new Date(a.samplingDate).getTime())
    , [abwLogs, pond.id]);
    
    const getUserName = (id?: number) => mockUsers.find(u => u.id === id)?.name || 'N/A';
    const hasShrimpLogs = pondLogs.some(log => log.cultureType === 'Shrimp');

    return (
        <div className="overflow-x-auto">
            <table className="w-full text-sm">
                <thead className="bg-slate-50">
                    <tr>
                        <th className="th-cell">Date</th>
                        <th className="th-cell">Species</th>
                        <th className="th-cell">ABW (g)</th>
                        {hasShrimpLogs && <th className="th-cell">Count (pcs/kg)</th>}
                        <th className="th-cell">Δ ABW</th>
                        {hasShrimpLogs && <th className="th-cell">Δ Count</th>}
                        <th className="th-cell">FCR</th>
                        <th className="th-cell">Cum. FCR</th>
                        <th className="th-cell">Recorded By</th>
                        <th className="th-cell"></th>
                    </tr>
                </thead>
                <tbody>
                    {pondLogs.map(log => {
                        const abwDeltaColor = log.abwGrowthDelta < 0 ? 'text-red-600' : 'text-green-600';
                        const countDeltaColor = log.countGrowthDelta && log.countGrowthDelta > 0 ? 'text-red-600' : 'text-green-600'; // Higher count is worse for shrimp
                        return (
                            <tr key={log.id} className="tr-cell">
                                <td className="td-cell">{new Date(log.samplingDate).toLocaleDateString()}</td>
                                <td className="td-cell">{log.speciesName}</td>
                                <td className="td-cell font-bold">{log.calculatedAbw.toFixed(2)}</td>
                                {hasShrimpLogs && <td className="td-cell">{log.cultureType === 'Shrimp' ? log.calculatedCount?.toFixed(1) ?? 'N/A' : 'N/A'}</td>}
                                <td className={`td-cell font-medium ${abwDeltaColor}`}>{log.abwGrowthDelta >= 0 ? `+${log.abwGrowthDelta.toFixed(2)}` : log.abwGrowthDelta.toFixed(2)}</td>
                                {hasShrimpLogs && <td className={`td-cell font-medium ${countDeltaColor}`}>{log.cultureType === 'Shrimp' && log.countGrowthDelta ? log.countGrowthDelta.toFixed(1) : 'N/A'}</td>}
                                <td className="td-cell">{log.fcrThisPeriod?.toFixed(2) ?? 'N/A'}</td>
                                <td className="td-cell">{log.fcrCumulative?.toFixed(2) ?? 'N/A'}</td>
                                <td className="td-cell">{getUserName(log.recordedById)}</td>
                                <td className="td-cell"><button onClick={() => deleteABWLog(log.id)} className="p-1 text-slate-400 hover:text-red-500"><Trash2 size={16}/></button></td>
                            </tr>
                        )
                    })}
                </tbody>
            </table>
            {pondLogs.length === 0 && <p className="text-center text-slate-500 py-6">No ABW logs for this pond.</p>}
            <style>{`.th-cell{padding:8px 12px; text-align:left; font-weight:600; color:#475569;} .tr-cell:hover{background-color:#f8fafc;} .td-cell{padding:8px 12px; border-top:1px solid #e2e8f0; color:#334155;}`}</style>
        </div>
    );
};

const ApplicationHistoryTab: React.FC<{ pond: Pond }> = ({ pond }) => {
    const { applicationLogs, transactions, deleteApplicationLog } = useData();
    const { user } = useAuth();
    const pondLogs = useMemo(() => applicationLogs.filter(r => r.pondId === pond.id), [applicationLogs, pond.id]);
    const getUserName = (id?: number) => mockUsers.find(u => u.id === id)?.name || 'N/A';
    
    return (
        <div className="overflow-x-auto">
            <table className="w-full text-sm">
                <thead className="bg-slate-50">
                    <tr>
                        <th className="th-cell">Date</th>
                        <th className="th-cell">Item</th>
                        <th className="th-cell">Quantity</th>
                        <th className="th-cell">Purpose</th>
                        <th className="th-cell">Category</th>
                        <th className="th-cell">Expense</th>
                        <th className="th-cell">Applied By</th>
                        <th className="th-cell"></th>
                    </tr>
                </thead>
                <tbody>
                    {pondLogs.map(log => {
                        const expense = transactions.find(t => t.id === log.transactionId)?.amount;
                        return (
                            <tr key={log.id} className="tr-cell">
                                <td className="td-cell">{new Date(log.date).toLocaleDateString()}</td>
                                <td className="td-cell">{log.productName}</td>
                                <td className="td-cell">{log.quantityUsed} {log.unit}</td>
                                <td className="td-cell">{log.purpose || '-'}</td>
                                <td className="td-cell">{log.category}</td>
                                <td className="td-cell">{expense ? `$${expense.toFixed(2)}` : 'N/A'}</td>
                                <td className="td-cell">{getUserName(log.recordedById)}</td>
                                <td className="td-cell">
                                    <button onClick={() => deleteApplicationLog(log.id)} className="p-1 text-slate-400 hover:text-red-500">
                                        <Trash2 size={16}/>
                                    </button>
                                </td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
            {pondLogs.length === 0 && <p className="text-center text-slate-500 py-6">No application logs for this pond.</p>}
            <style>{`.th-cell{padding:8px 12px; text-align:left; font-weight:600; color:#475569;} .tr-cell:hover{background-color:#f8fafc;} .td-cell{padding:8px 12px; border-top:1px solid #e2e8f0; color:#334155;}`}</style>
        </div>
    );
}

// --- FORM COMPONENTS ---

const MortalityForm: React.FC<{pond: Pond, onCancel: () => void}> = ({pond, onCancel}) => {
    const { user } = useAuth();
    const { addMortalityLogs, abwLogs } = useData();
    
    interface MortalityEntry {
        speciesName: string;
        currentStock: number;
        abwAtEntry: number; // in kg
        mortality: number;
        remarks: string;
    }

    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [entries, setEntries] = useState<MortalityEntry[]>(() => 
        pond.stock.map(s => {
            const latestABWLog = abwLogs
                .filter(log => log.pondId === pond.id && log.speciesName === s.species)
                .sort((a, b) => new Date(b.samplingDate).getTime() - new Date(a.samplingDate).getTime())[0];
            
            const abwInGrams = latestABWLog ? latestABWLog.calculatedAbw : s.initialABW;
            
            return {
                speciesName: s.species,
                currentStock: s.count,
                abwAtEntry: abwInGrams / 1000,
                mortality: 0,
                remarks: '',
            };
        })
    );
    
    const handleEntryChange = (index: number, field: 'mortality' | 'remarks', value: string | number) => {
        const newEntries = [...entries];
        const entry = newEntries[index];
        if (field === 'mortality') {
             const mortalityValue = Number(value);
             entry.mortality = mortalityValue > entry.currentStock ? entry.currentStock : mortalityValue;
        } else {
            entry.remarks = String(value);
        }
        setEntries(newEntries);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;
        
        const logsToSubmit = entries
            .filter(entry => entry.mortality > 0)
            .map(entry => ({
                pondId: pond.id,
                speciesName: entry.speciesName,
                mortality: entry.mortality,
                abwAtEntry: entry.abwAtEntry,
                remarks: entry.remarks,
                date: new Date(date).toISOString(),
            }));

        if (logsToSubmit.length > 0) {
            addMortalityLogs(logsToSubmit, pond.id, user.id);
        }
        onCancel();
    };

    return (
     <form onSubmit={handleSubmit} className="space-y-4">
        <div>
            <label className="label-style">Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} className="form-input" required />
        </div>
        <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-2">
            {entries.map((entry, index) => (
                <div key={entry.speciesName} className="p-3 bg-slate-50 rounded-lg border">
                    <h4 className="font-semibold text-slate-800">{entry.speciesName}</h4>
                    <p className="text-xs text-slate-500 mb-2">Current Stock: {entry.currentStock.toLocaleString()}</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                         <div>
                            <label className="label-style">Mortality Count</label>
                            <input 
                                type="number" 
                                value={entry.mortality}
                                onChange={e => handleEntryChange(index, 'mortality', parseInt(e.target.value) || 0)}
                                max={entry.currentStock}
                                className="form-input" 
                            />
                        </div>
                        <div>
                            <label className="label-style">Remarks (optional)</label>
                            <input 
                                type="text" 
                                value={entry.remarks}
                                onChange={e => handleEntryChange(index, 'remarks', e.target.value)}
                                className="form-input"
                             />
                        </div>
                    </div>
                </div>
            ))}
        </div>
        <div className="flex justify-end gap-2 border-t pt-4 mt-2">
            <button type="button" onClick={onCancel} className="btn-secondary">Cancel</button>
            <button type="submit" className="btn-primary">Save Log</button>
        </div>
         <style>{`.label-style {display:block; font-size: 0.875rem; color: #475569; margin-bottom: 0.25rem;} .btn-primary{background-color:#0891b2; color:white; padding:8px 16px; border-radius:6px;} .btn-secondary{background-color:#f1f5f9; color:#334155; padding:8px 16px; border-radius:6px;}`}</style>
    </form>
    );
};
const ABWForm: React.FC<{pond: Pond, onCancel: () => void}> = ({pond, onCancel}) => {
    const { user } = useAuth();
    const { addABWLogs, abwLogs, feedingEvents } = useData();

    interface ABWEntry extends Omit<ABWLog, 'id' | 'pondId' | 'recordedById'> {
        previousAbw: number;
        previousCount?: number;
        previousDate: string;
    }

    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [entries, setEntries] = useState<Partial<ABWEntry>[]>([]);

    useEffect(() => {
        const initialEntries = pond.stock.map((stockItem): Partial<ABWEntry> => {
            const isShrimp = CULTURE_SPECIES_MAP['🦐 Shrimp'].includes(stockItem.species);
            const lastLog = abwLogs
                .filter(log => log.pondId === pond.id && log.speciesName === stockItem.species)
                .sort((a,b) => new Date(b.samplingDate).getTime() - new Date(a.samplingDate).getTime())[0];

            return {
                speciesName: stockItem.species,
                cultureType: isShrimp ? 'Shrimp' : 'Fish',
                samplingNumber: undefined,
                samplingWeight: undefined,
                previousAbw: lastLog ? lastLog.calculatedAbw : stockItem.initialABW,
                previousCount: lastLog ? lastLog.calculatedCount : (isShrimp ? (1000 / stockItem.initialABW) : undefined),
                previousDate: lastLog ? lastLog.samplingDate : pond.stockingDate,
            };
        });
        setEntries(initialEntries);
    }, [pond, abwLogs]);
    
    const entriesDep = useMemo(() => {
        return entries.map(e => `${e.samplingNumber}-${e.samplingWeight}`).join(',');
    }, [entries]);

    useEffect(() => {
        const allSpeciesPreviousBiomass: { species: string; biomass: number; }[] = pond.stock.map(stockItem => {
            const lastLog = abwLogs
                .filter(log => log.pondId === pond.id && log.speciesName === stockItem.species)
                .sort((a,b) => new Date(b.samplingDate).getTime() - new Date(a.samplingDate).getTime())[0];
            const prevAbw = lastLog ? lastLog.calculatedAbw : stockItem.initialABW;
            return { species: stockItem.species, biomass: (prevAbw / 1000) * stockItem.count };
        });
        const totalPreviousBiomass = allSpeciesPreviousBiomass.reduce((sum, item) => sum + item.biomass, 0);

        setEntries(currentEntries => currentEntries.map(entry => {
            if (!entry.speciesName || !entry.cultureType || !entry.previousAbw === undefined || !entry.previousDate) return entry;
            
            let newAbw = 0;
            let newCount: number | undefined = undefined;

            const samplingNumber = entry.samplingNumber || 0;
            const samplingWeight = entry.samplingWeight || 0;

            if (entry.cultureType === 'Shrimp' && samplingNumber > 0 && samplingWeight > 0) {
                newAbw = samplingWeight / samplingNumber;
                newCount = 1000 / newAbw;
            } else if (entry.cultureType === 'Fish' && samplingNumber > 0 && samplingWeight > 0) {
                newAbw = samplingWeight / samplingNumber;
            }
            
            const abwGrowthDelta = newAbw - (entry.previousAbw || 0);
            const countGrowthDelta = entry.cultureType === 'Shrimp' && newCount !== undefined ? newCount - (entry.previousCount || 0) : undefined;
            
            const currentStock = pond.stock.find(s => s.species === entry.speciesName)?.count || 0;
            const biomassGainKg = (abwGrowthDelta / 1000) * currentStock;
            
            const totalFeedUsedSinceLastSampling = feedingEvents
                .filter(f => f.pondId === pond.id && new Date(f.time) > new Date(entry.previousDate) && new Date(f.time) <= new Date(date))
                .reduce((sum, f) => sum + f.quantity, 0);

            const speciesPreviousBiomass = allSpeciesPreviousBiomass.find(b => b.species === entry.speciesName)?.biomass || 0;
            const feedProportion = totalPreviousBiomass > 0 ? speciesPreviousBiomass / totalPreviousBiomass : 0;
            const allocatedFeedThisPeriod = totalFeedUsedSinceLastSampling * feedProportion;

            const fcrThisPeriod = biomassGainKg > 0 ? allocatedFeedThisPeriod / biomassGainKg : undefined;

            const totalFeedUsedCumulative = feedingEvents
                .filter(f => f.pondId === pond.id && new Date(f.time) > new Date(pond.stockingDate) && new Date(f.time) <= new Date(date))
                .reduce((sum, f) => sum + f.quantity, 0);
            
            const allocatedFeedCumulative = totalFeedUsedCumulative * feedProportion;
            
            const initialAbw = pond.stock.find(s => s.species === entry.speciesName)?.initialABW || 0;
            const totalBiomassGainKg = ((newAbw - initialAbw) / 1000) * currentStock;
            
            const fcrCumulative = totalBiomassGainKg > 0 ? allocatedFeedCumulative / totalBiomassGainKg : undefined;

            return {
                ...entry,
                calculatedAbw: newAbw,
                calculatedCount: newCount,
                abwGrowthDelta,
                countGrowthDelta,
                fcrThisPeriod,
                fcrCumulative
            };
        }));
    }, [entriesDep, date, pond, feedingEvents, abwLogs]);

    const handleEntryChange = (index: number, field: 'samplingNumber' | 'samplingWeight', value: string) => {
        const newEntries = [...entries];
        const currentEntry = newEntries[index];
        if (currentEntry) {
            newEntries[index] = { ...currentEntry, [field]: Number(value) || undefined };
            setEntries(newEntries);
        }
    }
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;
        
        const logsToSubmit: Omit<ABWLog, 'id'>[] = entries
            .filter((e): e is ABWEntry => e.calculatedAbw !== undefined && e.calculatedAbw > 0 && e.samplingNumber !== undefined && e.samplingWeight !== undefined)
            .map(e => ({
                pondId: pond.id,
                speciesName: e.speciesName,
                samplingDate: new Date(date).toISOString(),
                cultureType: e.cultureType,
                samplingNumber: e.samplingNumber,
                samplingWeight: e.samplingWeight,
                calculatedAbw: e.calculatedAbw,
                calculatedCount: e.calculatedCount,
                abwGrowthDelta: e.abwGrowthDelta,
                countGrowthDelta: e.countGrowthDelta,
                fcrThisPeriod: e.fcrThisPeriod,
                fcrCumulative: e.fcrCumulative,
                recordedById: user.id
            }));
        
        if (logsToSubmit.length > 0) {
            addABWLogs(logsToSubmit);
        }
        onCancel();
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label className="label-style">Sampling Date</label>
                <input type="date" value={date} onChange={e => setDate(e.target.value)} className="form-input" required />
            </div>
            <div className="space-y-4 max-h-[60vh] overflow-y-auto p-2">
                {entries.map((entry, index) => {
                     const abwDeltaColor = entry.abwGrowthDelta && entry.abwGrowthDelta < 0 ? 'text-red-600' : 'text-green-600';
                     return (
                        <div key={entry.speciesName} className="p-3 bg-slate-50 rounded-lg border">
                            <h4 className="font-semibold text-slate-800">{entry.speciesName}</h4>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-2">
                                {entry.cultureType === 'Shrimp' ? (
                                    <>
                                        <div><label className="label-style">No. of pieces</label><input type="number" value={entry.samplingNumber || ''} onChange={e => handleEntryChange(index, 'samplingNumber', e.target.value)} className="form-input"/></div>
                                        <div><label className="label-style">Total weight (g)</label><input type="number" step="any" value={entry.samplingWeight || ''} onChange={e => handleEntryChange(index, 'samplingWeight', e.target.value)} className="form-input"/></div>
                                        <div><label className="label-style">ABW (g)</label><input value={entry.calculatedAbw?.toFixed(2) || '0.00'} className="form-input" disabled /></div>
                                        <div><label className="label-style">Count (pcs/kg)</label><input value={entry.calculatedCount?.toFixed(1) || 'N/A'} className="form-input" disabled /></div>
                                    </>
                                ) : ( // Fish
                                    <>
                                        <div><label className="label-style">Sampling Number</label><input type="number" value={entry.samplingNumber || ''} onChange={e => handleEntryChange(index, 'samplingNumber', e.target.value)} className="form-input"/></div>
                                        <div><label className="label-style">Sampling Weight (g)</label><input type="number" step="any" value={entry.samplingWeight || ''} onChange={e => handleEntryChange(index, 'samplingWeight', e.target.value)} className="form-input"/></div>
                                        <div className="md:col-span-2"><label className="label-style">ABW (g)</label><input value={entry.calculatedAbw?.toFixed(2) || '0.00'} className="form-input" disabled /></div>
                                    </>
                                )}
                            </div>
                            <div className="mt-4 pt-3 border-t grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                                <div><span className="font-medium text-slate-500">Prev. ABW</span><p>{entry.previousAbw?.toFixed(2)}g</p></div>
                                <div><span className="font-medium text-slate-500">Growth</span><p className={`font-bold ${abwDeltaColor}`}>{entry.abwGrowthDelta?.toFixed(2) ?? '0.00'}g</p></div>
                                <div><span className="font-medium text-slate-500">FCR (Period)</span><p className="font-bold">{entry.fcrThisPeriod?.toFixed(2) ?? 'N/A'}</p></div>
                                <div><span className="font-medium text-slate-500">FCR (Cum.)</span><p className="font-bold">{entry.fcrCumulative?.toFixed(2) ?? 'N/A'}</p></div>
                            </div>
                        </div>
                    )
                })}
            </div>
             <div className="flex justify-end gap-2 border-t pt-4 mt-2">
                <button type="button" onClick={onCancel} className="btn-secondary">Cancel</button>
                <button type="submit" className="btn-primary">Save Log</button>
            </div>
            <style>{`.label-style {display:block; font-size: 0.875rem; color: #475569; margin-bottom: 0.25rem;} .btn-primary{background-color:#0891b2; color:white; padding:8px 16px; border-radius:6px;} .btn-secondary{background-color:#f1f5f9; color:#334155; padding:8px 16px; border-radius:6px;}`}</style>
        </form>
    );
};

const ApplicationForm: React.FC<{pond: Pond, onCancel: () => void}> = ({pond, onCancel}) => {
    const { user } = useAuth();
    const { inventory, addApplicationLogs } = useData();

    type FormEntry = {
        inventoryItemId: string;
        quantityUsed: string;
        purpose: string;
        remarks: string;
    };

    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [entries, setEntries] = useState<FormEntry[]>([{ inventoryItemId: '', quantityUsed: '', purpose: '', remarks: '' }]);
    const [error, setError] = useState('');

    const siteSupplements = useMemo(() => inventory.filter(i => 
        i.siteId === pond.siteId && 
        (i.category === 'Pond Supplements' || i.category === 'Feed Supplements') &&
        i.quantity > 0
    ), [inventory, pond.siteId]);

    const handleEntryChange = (index: number, field: keyof FormEntry, value: string) => {
        const newEntries = [...entries];
        newEntries[index] = { ...newEntries[index], [field]: value };
        setEntries(newEntries);
    };

    const addEntry = () => setEntries([...entries, { inventoryItemId: '', quantityUsed: '', purpose: '', remarks: '' }]);
    const removeEntry = (index: number) => setEntries(entries.filter((_, i) => i !== index));

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!user) return;

        const logsToSubmit: Omit<ApplicationLog, 'id' | 'siteId' | 'productName' | 'category' | 'unit' | 'transactionId'>[] = [];

        for (const entry of entries) {
            if (entry.inventoryItemId && entry.quantityUsed) {
                const item = inventory.find(i => i.id === parseInt(entry.inventoryItemId));
                const quantity = parseFloat(entry.quantityUsed);

                if (!item || quantity <= 0) {
                    setError('Please ensure all selected products and quantities are valid.');
                    return;
                }
                if (item.quantity < quantity) {
                    setError(`Not enough stock for ${item.name}. Available: ${item.quantity}, Required: ${quantity}.`);
                    return;
                }

                logsToSubmit.push({
                    pondId: pond.id,
                    inventoryItemId: parseInt(entry.inventoryItemId),
                    quantityUsed: quantity,
                    purpose: entry.purpose,
                    remarks: entry.remarks,
                    recordedById: user.id,
                    date: new Date(date).toISOString()
                });
            }
        }
        
        if (logsToSubmit.length === 0) {
             setError('Please add at least one valid product application.');
            return;
        }
        
        try {
            addApplicationLogs(logsToSubmit);
            onCancel();
        } catch (e: any) {
            setError(e.message || "An error occurred while saving.");
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label className="label-style">Application Date</label>
                <input type="date" value={date} onChange={e => setDate(e.target.value)} className="form-input" required />
            </div>
            <div className="space-y-3 max-h-[50vh] overflow-y-auto -mr-2 pr-2">
                {entries.map((entry, index) => {
                    const selectedItem = inventory.find(i => i.id === parseInt(entry.inventoryItemId));
                    return (
                        <div key={index} className="p-3 bg-slate-50 rounded-lg border relative">
                             {entries.length > 1 && (
                                <button type="button" onClick={() => removeEntry(index)} className="absolute top-1 right-1 p-1 text-red-400 hover:text-red-600 rounded-full hover:bg-red-100">
                                    <X size={16}/>
                                </button>
                            )}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className="label-style">Product</label>
                                    <select 
                                        value={entry.inventoryItemId} 
                                        onChange={e => handleEntryChange(index, 'inventoryItemId', e.target.value)}
                                        className="form-input form-select"
                                        required
                                    >
                                        <option value="">-- Select --</option>
                                        {siteSupplements.map(s => <option key={s.id} value={s.id}>{s.name} ({s.quantity} {s.unit})</option>)}
                                    </select>
                                </div>
                                <div>
                                    <label className="label-style">Quantity Used</label>
                                    <div className="relative">
                                        <input 
                                            type="number" 
                                            step="0.01" 
                                            value={entry.quantityUsed}
                                            onChange={e => handleEntryChange(index, 'quantityUsed', e.target.value)}
                                            className="form-input pr-12" 
                                            required 
                                        />
                                        {selectedItem && <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-500 text-sm">{selectedItem.unit}</span>}
                                    </div>
                                </div>
                                <div className="md:col-span-2">
                                    <label className="label-style">Purpose (optional)</label>
                                    <input type="text" value={entry.purpose} onChange={e => handleEntryChange(index, 'purpose', e.target.value)} className="form-input" />
                                </div>
                                 <div className="md:col-span-2">
                                    <label className="label-style">Remarks (optional)</label>
                                    <input type="text" value={entry.remarks} onChange={e => handleEntryChange(index, 'remarks', e.target.value)} className="form-input" />
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
            <button type="button" onClick={addEntry} className="text-sm text-cyan-600 flex items-center gap-1 hover:underline">
                <PlusCircle size={16}/> Add another product
            </button>
            {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md">{error}</p>}
            <div className="flex justify-end gap-2 border-t pt-4 mt-2">
                <button type="button" onClick={onCancel} className="btn-secondary">Cancel</button>
                <button type="submit" className="btn-primary">Save Applications</button>
            </div>
            <style>{`.label-style {display:block; font-size: 0.875rem; color: #475569; margin-bottom: 0.25rem;} .btn-primary{background-color:#0891b2; color:white; padding:8px 16px; border-radius:6px;} .btn-secondary{background-color:#f1f5f9; color:#334155; padding:8px 16px; border-radius:6px;}`}</style>
        </form>
    );
};

const HarvestForm: React.FC<{pond: Pond, onCancel: () => void}> = ({pond, onCancel}) => {
    const { user } = useAuth();
    const { addHarvestLogs } = useData();

    interface HarvestEntry {
        speciesName: string;
        currentStock: number;
        numberHarvested: number;
        totalWeight: number; // kg
        costPerKg?: number;
        remarks?: string;
    }

    const [harvestType, setHarvestType] = useState<HarvestType>('Partial');
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [entries, setEntries] = useState<HarvestEntry[]>(() =>
        pond.stock.map(s => ({
            speciesName: s.species,
            currentStock: s.count,
            numberHarvested: 0,
            totalWeight: 0,
        }))
    );
    const [error, setError] = useState('');

    const handleEntryChange = (index: number, field: keyof HarvestEntry, value: string | number) => {
        const newEntries = [...entries];
        const entry = newEntries[index];

        if (field === 'numberHarvested') {
            const numValue = Number(value);
            entry[field] = numValue > entry.currentStock ? entry.currentStock : numValue;
        } else if (field === 'totalWeight' || field === 'costPerKg') {
             entry[field] = Number(value);
        } else if (field === 'remarks') {
             entry[field] = String(value);
        }
        setEntries(newEntries);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!user) return;

        const logsToSubmit = entries
            .filter(entry => entry.numberHarvested > 0)
            .map(entry => {
                if(entry.totalWeight <= 0) {
                    setError(`Total weight must be positive for ${entry.speciesName}.`);
                    return null;
                }
                return {
                    pondId: pond.id,
                    speciesName: entry.speciesName,
                    harvestType: harvestType,
                    numberHarvested: entry.numberHarvested,
                    totalWeight: entry.totalWeight,
                    costPerKg: entry.costPerKg,
                    remarks: entry.remarks,
                    date: new Date(date).toISOString(),
                    recordedById: user.id,
                }
            });
        
        if(logsToSubmit.includes(null)) return;
        
        if (logsToSubmit.length > 0) {
            addHarvestLogs(logsToSubmit as Omit<HarvestLog, 'id' | 'abw' | 'value' | 'transactionId'>[]);
        }
        onCancel();
    };

    useEffect(() => {
        if(harvestType === 'Full') {
            setEntries(prev => prev.map(e => ({ ...e, numberHarvested: e.currentStock })));
        } else {
            setEntries(prev => prev.map(e => ({ ...e, numberHarvested: 0 })));
        }
    }, [harvestType]);

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
             <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="label-style">Harvest Type</label>
                    <select value={harvestType} onChange={e => setHarvestType(e.target.value as HarvestType)} className="form-input form-select">
                        <option value="Partial">Partial Harvest</option>
                        <option value="Full">Full Harvest</option>
                    </select>
                 </div>
                 <div>
                    <label className="label-style">Date</label>
                    <input type="date" value={date} onChange={e => setDate(e.target.value)} className="form-input" required />
                 </div>
             </div>
             <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-2">
                 {entries.map((entry, index) => {
                    const abw = entry.numberHarvested > 0 ? (entry.totalWeight / entry.numberHarvested) * 1000 : 0;
                    const value = entry.costPerKg ? entry.totalWeight * entry.costPerKg : 0;
                    return (
                        <div key={entry.speciesName} className="p-3 bg-slate-50 rounded-lg border">
                            <h4 className="font-semibold text-slate-800">{entry.speciesName}</h4>
                            <p className="text-xs text-slate-500 mb-2">Current Stock: {entry.currentStock.toLocaleString()}</p>
                            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 items-end">
                                <div><label className="label-style">No. Harvested</label><input type="number" value={entry.numberHarvested} onChange={e => handleEntryChange(index, 'numberHarvested', e.target.value)} max={entry.currentStock} className="form-input" /></div>
                                <div><label className="label-style">Weight (kg)</label><input type="number" step="0.01" value={entry.totalWeight} onChange={e => handleEntryChange(index, 'totalWeight', e.target.value)} className="form-input" /></div>
                                <div><label className="label-style">Cost/kg</label><input type="number" step="0.01" placeholder="Optional" value={entry.costPerKg || ''} onChange={e => handleEntryChange(index, 'costPerKg', e.target.value)} className="form-input" /></div>
                                <div><label className="label-style">ABW (g)</label><input value={abw.toFixed(1)} className="form-input" disabled /></div>
                                <div className="lg:col-span-3"><label className="label-style">Remarks</label><input type="text" placeholder="Optional" value={entry.remarks || ''} onChange={e => handleEntryChange(index, 'remarks', e.target.value)} className="form-input" /></div>
                                <div><label className="label-style">Value</label><input value={`$${value.toFixed(2)}`} className="form-input" disabled /></div>
                            </div>
                        </div>
                    )
                 })}
             </div>
             {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md">{error}</p>}
             <div className="flex justify-end gap-2 border-t pt-4 mt-2">
                 <button type="button" onClick={onCancel} className="btn-secondary">Cancel</button>
                 <button type="submit" className="btn-primary">Save Harvest</button>
             </div>
            <style>{`.label-style {display:block; font-size: 0.875rem; color: #475569; margin-bottom: 0.25rem;} .btn-primary{background-color:#0891b2; color:white; padding:8px 16px; border-radius:6px;} .btn-secondary{background-color:#f1f5f9; color:#334155; padding:8px 16px; border-radius:6px;}`}</style>
        </form>
    );
};
const WaterQualityForm: React.FC<{pond: Pond, onSubmit: (e: React.FormEvent<HTMLFormElement>) => void, onCancel: () => void}> = ({pond, onSubmit, onCancel}) => {
    const { user } = useAuth();
    const renderRange = (key: RangeKey) => {
      const range = RANGES[key];
      if (!range) return '';
      if (range.min !== undefined && range.max !== undefined) return `(${range.min} - ${range.max})`;
      if (range.min !== undefined) return `(> ${range.min})`;
      if (range.max !== undefined) return `(< ${range.max})`;
      return '';
    };

    return (
        <form onSubmit={onSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
                <div><label className="label-style">Pond</label><input value={pond.name} className="form-input" disabled /></div>
                <div><label className="label-style">Date</label><input type="date" name="date" defaultValue={new Date().toISOString().split('T')[0]} className="form-input" required /></div>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <fieldset className="space-y-4 p-4 border rounded-lg">
                    <legend className="px-2 font-semibold text-cyan-700">Chemical Analysis</legend>
                    <div className="grid grid-cols-2 gap-4">
                        {chemicalFields.map(key => (
                            <div key={key}>
                                <label className="label-style">
                                    {RANGES[key]?.label || key} <span className="text-xs text-slate-400">{renderRange(key)}</span>
                                    {key === 'hardness' && <span className="inline-block" title="Varies depending on salinity"><Info size={12} className="inline ml-1 text-slate-400" /></span>}
                                </label>
                                <input type="number" step="any" name={key} className="form-input" />
                            </div>
                        ))}
                    </div>
                </fieldset>
                <fieldset className="space-y-4 p-4 border rounded-lg">
                    <legend className="px-2 font-semibold text-cyan-700">Toxic Gases & DO</legend>
                    <div className="grid grid-cols-2 gap-4">
                        {gasFields.map(key => (
                            <div key={key}>
                                <label className="label-style">{RANGES[key]?.label || key} <span className="text-xs text-slate-400">{renderRange(key)}</span></label>
                                <input type="number" step="any" name={key} className="form-input" />
                            </div>
                        ))}
                    </div>
                </fieldset>
            </div>
             <div>
                <label className="label-style">Remarks (optional)</label>
                <textarea name="remarks" className="form-input" rows={2}></textarea>
            </div>
            <div className="flex justify-end gap-3 pt-4 border-t">
                <button type="button" onClick={onCancel} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-md hover:bg-slate-200">Cancel</button>
                <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700">Save Reading</button>
            </div>
             <style>{`.label-style { display: block; margin-bottom: 0.25rem; font-size: 0.875rem; font-weight: 500; color: #475569; }`}</style>
        </form>
    )
};
const FeedForm: React.FC<{pond: Pond, feedDate: string, setFeedDate: (d: string) => void, slotData: Record<string, SlotData>, setSlotData: (d: Record<string, SlotData> | ((prevState: Record<string, SlotData>) => Record<string, SlotData>)) => void, onSubmit: (e: React.FormEvent<HTMLFormElement>) => void, onCancel: () => void}> = ({pond, feedDate, setFeedDate, slotData, setSlotData, onSubmit, onCancel}) => {
    const { inventory } = useData();
    
    const feedSpeciesGroups: { type: CultureType; species: string[]; }[] = useMemo(() => {
        if (pond.cultureType === '🌀 Mixed / Polyculture') {
            return getCultureSpeciesGroups(pond);
        }
        return [{ type: pond.cultureType, species: pond.stock.map(s => s.species) }];
    }, [pond]);

    const handleSlotChange = (groupIndex: number, slotIndex: number, field: keyof SlotData, value: any) => {
        const key = `${groupIndex}-${slotIndex}`;
        setSlotData((prev: Record<string, SlotData>) => ({
            ...prev,
            [key]: {
                ...(prev[key] || { quantity: 0, supplements: [] }),
                [field]: value
            }
        }));
    };
    
    const handleSupplementChange = (groupIndex: number, slotIndex: number, suppIndex: number, field: 'inventoryItemId' | 'quantityUsed', value: any) => {
        const key = `${groupIndex}-${slotIndex}`;
        const currentSlotData = slotData[key] || { quantity: 0, supplements: [] };
        const updatedSupplements = [...currentSlotData.supplements];
        if(!updatedSupplements[suppIndex]) updatedSupplements[suppIndex] = { inventoryItemId: 0, quantityUsed: 0 };
        updatedSupplements[suppIndex] = { ...updatedSupplements[suppIndex], [field]: value };

        setSlotData((prev: Record<string, SlotData>) => ({
            ...prev,
            [key]: { ...currentSlotData, supplements: updatedSupplements.filter(s => s.inventoryItemId) }
        }));
    };
    
    const addSupplementRow = (groupIndex: number, slotIndex: number) => {
        const key = `${groupIndex}-${slotIndex}`;
        const currentSlotData = slotData[key] || { quantity: 0, supplements: [] };
        const updatedSupplements = [...currentSlotData.supplements, { inventoryItemId: 0, quantityUsed: 0 }];
        setSlotData((prev: Record<string, SlotData>) => ({ ...prev, [key]: { ...currentSlotData, supplements: updatedSupplements } }));
    };

    const removeSupplementRow = (groupIndex: number, slotIndex: number, suppIndex: number) => {
        const key = `${groupIndex}-${slotIndex}`;
        const currentSlotData = slotData[key];
        if (!currentSlotData) return;
        const updatedSupplements = currentSlotData.supplements.filter((_, i) => i !== suppIndex);
        setSlotData((prev: Record<string, SlotData>) => ({ ...prev, [key]: { ...currentSlotData, supplements: updatedSupplements } }));
    };


    return (
        <form onSubmit={onSubmit} className="space-y-6">
            <div>
                <label className="label-style">Date</label>
                <input type="date" value={feedDate} onChange={(e) => setFeedDate(e.target.value)} className="form-input" />
            </div>
            
            {feedSpeciesGroups.map((group, groupIndex) => {
                const cultureSlots = CULTURE_FEEDING_SLOTS[group.type] || CULTURE_FEEDING_SLOTS['🌀 Mixed / Polyculture'];
                const availableFeeds = inventory.filter(i => i.category === 'Feed' && i.siteId === pond.siteId && (!i.applicableSpecies || i.applicableSpecies.some(s => group.species.includes(s))));
                const availableSupplements = inventory.filter(i => i.siteId === pond.siteId && i.category.includes('Supplement'));

                return (
                    <div key={group.type} className="space-y-4 p-4 border rounded-lg bg-slate-50">
                        {feedSpeciesGroups.length > 1 && <h4 className="text-lg font-semibold text-slate-700">{group.type} Feeding</h4>}
                        
                        {cultureSlots.labels.map((label, slotIndex) => {
                            const key = `${groupIndex}-${slotIndex}`;
                            const currentSlotData = slotData[key] || { quantity: 0, supplements: [] };
                            return (
                                <div key={slotIndex} className="p-3 border-b last:border-b-0">
                                    <h5 className="font-semibold mb-2">{label}</h5>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="label-style">Feed Item</label>
                                            <select 
                                                className="form-input form-select" 
                                                value={currentSlotData.inventoryFeedId || ''}
                                                onChange={(e) => handleSlotChange(groupIndex, slotIndex, 'inventoryFeedId', parseInt(e.target.value))}
                                            >
                                                <option value="">-- Select Feed --</option>
                                                {availableFeeds.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                                            </select>
                                        </div>
                                        <div>
                                            <label className="label-style">Quantity (kg)</label>
                                            <input 
                                                type="number" 
                                                step="0.1"
                                                className="form-input"
                                                value={currentSlotData.quantity || ''}
                                                onChange={(e) => handleSlotChange(groupIndex, slotIndex, 'quantity', parseFloat(e.target.value) || 0)}
                                            />
                                        </div>
                                    </div>
                                    <div className="mt-4 space-y-2">
                                        <label className="label-style">Supplements</label>
                                        {currentSlotData.supplements.map((supp, suppIndex) => (
                                            <div key={suppIndex} className="grid grid-cols-12 gap-2 items-center">
                                                <div className="col-span-6"><select className="form-input form-select" value={supp.inventoryItemId || ''} onChange={(e) => handleSupplementChange(groupIndex, slotIndex, suppIndex, 'inventoryItemId', parseInt(e.target.value))}>
                                                     <option value="">-- Select --</option>
                                                     {availableSupplements.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                                                </select></div>
                                                <div className="col-span-4"><input type="number" step="0.01" className="form-input" placeholder="Qty" value={supp.quantityUsed || ''} onChange={(e) => handleSupplementChange(groupIndex, slotIndex, suppIndex, 'quantityUsed', parseFloat(e.target.value) || 0)} /></div>
                                                <div className="col-span-2"><button type="button" onClick={() => removeSupplementRow(groupIndex, slotIndex, suppIndex)} className="p-2 text-red-500 hover:bg-red-100 rounded-full"><X size={16}/></button></div>
                                            </div>
                                        ))}
                                        <button type="button" onClick={() => addSupplementRow(groupIndex, slotIndex)} className="text-sm text-cyan-600 flex items-center gap-1"><Plus size={14}/>Add Supplement</button>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                );
            })}

            <div className="flex justify-end gap-2 border-t pt-4 mt-2">
                <button type="button" onClick={onCancel} className="btn-secondary">Cancel</button>
                <button type="submit" className="btn-primary">Save Feed Log</button>
            </div>
            <style>{`.label-style {display:block; font-size: 0.875rem; color: #475569; margin-bottom: 0.25rem;} .btn-primary{background-color:#0891b2; color:white; padding:8px 16px; border-radius:6px;} .btn-secondary{background-color:#f1f5f9; color:#334155; padding:8px 16px; border-radius:6px;}`}</style>
        </form>
    );
};

export default PondDetail;
