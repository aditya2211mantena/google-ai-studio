
import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Filter, Download } from 'lucide-react';
import { useData } from '../contexts/DataContext';
import { mockUsers } from '../data/mockData';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#AF19FF', '#FF4560'];

const downloadCSV = (data: any[], filename: string) => {
    if (data.length === 0) {
        alert("No data to export.");
        return;
    }
    const headers = Object.keys(data[0]);
    const csvContent = [
        headers.join(','),
        ...data.map(row => headers.map(header => JSON.stringify(row[header])).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};


const Reports: React.FC = () => {
    const { transactions, harvestLogs, ponds, sites } = useData();

    const expenseData = useMemo(() => {
        const expenseMap = new Map<string, number>();
        transactions
            .filter(t => t.type === 'expense')
            .forEach(t => {
                let category = 'Other';
                if (t.description.toLowerCase().includes('feed')) category = 'Feed';
                else if (t.description.toLowerCase().includes('bill')) category = 'Utilities';
                else if (t.description.toLowerCase().includes('labor') || t.description.toLowerCase().includes('salary')) category = 'Labor';
                else if (t.description.toLowerCase().includes('purchase of fry') || t.description.toLowerCase().includes('purchase of pl')) category = 'Fry/PL';
                else if (t.description.toLowerCase().includes('medicine')) category = 'Medicine';
                
                expenseMap.set(category, (expenseMap.get(category) || 0) + t.amount);
            });
        return Array.from(expenseMap, ([name, value]) => ({ name, value }));
    }, [transactions]);

    const harvestDataByMonth = useMemo(() => {
        const harvestMap = new Map<string, number>();
         harvestLogs.forEach(log => {
            const month = new Date(log.date).toLocaleString('default', { month: 'short', year: '2-digit' });
            harvestMap.set(month, (harvestMap.get(month) || 0) + log.totalWeight);
        });
        return Array.from(harvestMap, ([month, totalKg]) => ({ month, totalKg }));
    }, [harvestLogs]);
    
    const formattedHarvestLogs = useMemo(() => harvestLogs.map(log => ({
        date: new Date(log.date).toLocaleString(),
        pondName: ponds.find(p => p.id === log.pondId)?.name || 'N/A',
        species: log.speciesName,
        type: log.harvestType,
        number_harvested: log.numberHarvested,
        weight_kg: log.totalWeight,
        abw_g: (log.abw * 1000).toFixed(2),
        value: log.value?.toFixed(2) ?? 'N/A',
        recorded_by: mockUsers.find(u => u.id === log.recordedById)?.name || 'N/A'
    })), [harvestLogs, ponds]);
    
    const formattedExpenseLogs = useMemo(() => transactions.filter(t=>t.type==='expense').map(log => ({
        date: new Date(log.date).toLocaleDateString(),
        description: log.description,
        siteName: sites.find(s => s.id === log.siteId)?.name || 'N/A',
        amount: log.amount,
    })), [transactions, sites]);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Reports & Analytics</h1>
        <p className="text-slate-500 mt-1">Visualize your farm's performance and historical data.</p>
      </header>

      <div className="bg-white p-4 md:p-6 rounded-xl shadow-md">
        <div className="flex items-center justify-between mb-4 border-b pb-4">
            <h3 className="text-lg font-semibold text-slate-800 flex items-center gap-2"><Filter size={20}/> Filters (Coming Soon)</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 opacity-50">
            <div>
                <label className="text-sm font-medium text-slate-600">Date Range</label>
                <input type="date" className="form-input mt-1" disabled/>
            </div>
             <div>
                <label className="text-sm font-medium text-slate-600">Site</label>
                <select className="form-input form-select mt-1" disabled><option>All Sites</option></select>
            </div>
             <div>
                <label className="text-sm font-medium text-slate-600">Report Type</label>
                <select className="form-input form-select mt-1" disabled><option>Financial</option></select>
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-4 md:p-6 rounded-xl shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-slate-800">Monthly Harvest (kg)</h3>
            <button onClick={() => downloadCSV(formattedHarvestLogs, 'harvest_report')} className="text-sm text-cyan-600 flex items-center gap-1 hover:underline"><Download size={14}/> Export CSV</button>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={harvestDataByMonth}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="month" tick={{fill: '#64748b', fontSize: 12}} />
              <YAxis tick={{fill: '#64748b', fontSize: 12}}/>
              <Tooltip wrapperClassName="!bg-white !border-slate-200 !rounded-md !shadow-lg" />
              <Legend />
              <Bar dataKey="totalKg" fill="#0ea5e9" name="Total Harvest (kg)" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white p-4 md:p-6 rounded-xl shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-slate-800">Expense Distribution</h3>
             <button onClick={() => downloadCSV(formattedExpenseLogs, 'expense_report')} className="text-sm text-cyan-600 flex items-center gap-1 hover:underline"><Download size={14}/> Export CSV</button>
          </div>
          <ResponsiveContainer width="100%" height={300}>
             <PieChart>
                <Pie data={expenseData} cx="50%" cy="50%" labelLine={false} outerRadius={110} fill="#8884d8" dataKey="value" nameKey="name" label={(entry) => entry.name}>
                    {expenseData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                </Pie>
                <Tooltip wrapperClassName="!bg-white !border-slate-200 !rounded-md !shadow-lg" />
                <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Reports;
