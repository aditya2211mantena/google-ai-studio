
import React from 'react';
import { useData } from '../contexts/DataContext';
import { ShieldAlert, Trash2, DatabaseZap } from 'lucide-react';

const Settings: React.FC = () => {
    const { seedSampleData, resetAllData } = useData();

    const handleReset = () => {
        if (window.confirm('DANGER: This will delete ALL current data and reset the application to its initial state. Are you sure you want to proceed?')) {
            resetAllData();
        }
    };

    return (
        <div className="space-y-8">
            <header>
                <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Settings & Developer Tools</h1>
                <p className="text-slate-500 mt-1">Manage application data for testing and development.</p>
            </header>

            <div className="bg-white p-6 rounded-xl shadow-lg">
                <h3 className="text-lg font-semibold text-slate-800 mb-4 border-b pb-3 flex items-center gap-2">
                    <DatabaseZap className="text-cyan-600" /> Data Seeding
                </h3>
                <p className="text-sm text-slate-600 mb-4">
                    Add randomly generated sample data to test the application with a larger dataset.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                    <button
                        onClick={() => seedSampleData('ponds')}
                        className="btn-primary-outline w-full sm:w-auto"
                    >
                        Add 3 Sample Ponds
                    </button>
                    <button
                        onClick={() => seedSampleData('logs')}
                        className="btn-primary-outline w-full sm:w-auto"
                    >
                        Add 50 Random Log Entries
                    </button>
                </div>
            </div>

            <div className="bg-red-50 border-2 border-dashed border-red-300 p-6 rounded-xl">
                 <h3 className="text-lg font-semibold text-red-800 mb-4 border-b border-red-200 pb-3 flex items-center gap-2">
                    <ShieldAlert /> Danger Zone
                </h3>
                 <p className="text-sm text-red-700 mb-4">
                    These actions are irreversible and will permanently alter your local application data.
                </p>
                <button
                    onClick={handleReset}
                    className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white font-semibold rounded-lg shadow-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-75"
                >
                    <Trash2 size={16} /> Reset All Data to Default
                </button>
            </div>
             <style>{`
                .btn-primary-outline { 
                    display:inline-flex; 
                    align-items:center; 
                    justify-content: center;
                    gap:0.5rem; 
                    padding: 0.5rem 1rem; 
                    background-color: #fff; 
                    color: #0891b2; 
                    border: 1px solid #0891b2;
                    border-radius: 0.5rem;
                    font-weight: 600;
                    transition: all 0.2s;
                }
                .btn-primary-outline:hover {
                    background-color: #0891b2;
                    color: white;
                    transform: translateY(-2px);
                    box-shadow: 0 4px 10px rgba(8, 145, 178, 0.3);
                }
            `}</style>
        </div>
    );
};

export default Settings;
