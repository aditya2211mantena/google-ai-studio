
import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Globe, PlusCircle, Edit, Trash2, RotateCcw, MapPin, ChevronDown, Archive, Wallet, Package, Beaker, GitCommit, AlertTriangle, ArrowUpCircle, ArrowDownCircle, Droplets, ChevronRight } from 'lucide-react';
import type { Site, Pond, InventoryItem, Transaction, CultureType } from '../types';
import Modal from './Modal';
import { useData } from '../contexts/DataContext';
import { CULTURE_SPECIES_MAP } from '../data/aquacultureData';


const TabButton: React.FC<{ active: boolean; onClick: () => void; children: React.ReactNode }> = ({ active, onClick, children }) => (
    <button
        onClick={onClick}
        className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-t-lg transition-colors ${
            active ? 'bg-white border-slate-200 border-b-white -mb-px' : 'text-slate-500 hover:bg-slate-100 bg-slate-50 border-transparent'
        } border`}
    >
        {children}
    </button>
);

const Sites: React.FC = () => {
    const { sites, addSite, updateSite, toggleSiteDeleted } = useData();
    const [isSiteModalOpen, setIsSiteModalOpen] = useState(false);
    const [currentSite, setCurrentSite] = useState<Partial<Site> | null>(null);
    const [coords, setCoords] = useState({ lat: 0, lng: 0 });
    const [showDeleted, setShowDeleted] = useState(false);

    const openSiteModal = (site: Partial<Site> | null = null) => {
        if (site) {
            setCurrentSite({ ...site });
            setCoords(site.geolocation || { lat: 0, lng: 0 });
        } else {
            setCurrentSite({ name: '', location: '', geolocation: { lat: 0, lng: 0 } });
            setCoords({ lat: 0, lng: 0 });
        }
        setIsSiteModalOpen(true);
    };

    const closeSiteModal = () => {
        setIsSiteModalOpen(false);
        setCurrentSite(null);
    };

    const handleSaveSite = (e: React.FormEvent) => {
        e.preventDefault();
        const form = e.target as HTMLFormElement;
        const siteData = {
            name: (form.elements.namedItem('name') as HTMLInputElement).value,
            location: (form.elements.namedItem('location') as HTMLInputElement).value,
            geolocation: {
                lat: parseFloat((form.elements.namedItem('lat') as HTMLInputElement).value || '0'),
                lng: parseFloat((form.elements.namedItem('lng') as HTMLInputElement).value || '0'),
            }
        };

        if (currentSite?.id) {
            updateSite({ ...currentSite, ...siteData } as Site);
        } else {
            addSite(siteData);
        }
        closeSiteModal();
    };

    const filteredSites = sites.filter(s => showDeleted ? s.isDeleted : !s.isDeleted);

    return (
        <div className="space-y-6">
            <header>
                <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Sites</h1>
                <p className="text-slate-500 mt-1">Manage your farm locations and their specific ponds, inventory and finances.</p>
            </header>
            
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-4">
                <div>
                    <button onClick={() => setShowDeleted(false)} className={`px-3 py-1 text-sm rounded-l-md transition-colors ${!showDeleted ? 'bg-cyan-600 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'}`}>Active</button>
                    <button onClick={() => setShowDeleted(true)} className={`px-3 py-1 text-sm rounded-r-md transition-colors ${showDeleted ? 'bg-red-500 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'}`}>Deleted</button>
                </div>
                <button onClick={() => openSiteModal()} className="bg-cyan-600 text-white px-4 py-2 rounded-md hover:bg-cyan-700 flex items-center justify-center">
                    <PlusCircle size={16} className="mr-2"/> Add Site
                </button>
            </div>
            
            <div className="space-y-4">
                {filteredSites.map(site => (
                    <SiteCard key={site.id} site={site} onEdit={() => openSiteModal(site)} onDelete={() => toggleSiteDeleted(site.id)} />
                ))}
                {filteredSites.length === 0 && <p className="text-center text-slate-500 py-8">No {showDeleted ? 'deleted' : 'active'} sites found.</p>}
            </div>

            <Modal isOpen={isSiteModalOpen} onClose={closeSiteModal} title={currentSite?.id ? 'Edit Site' : 'Add New Site'}>
                <SiteForm currentSite={currentSite} coords={coords} setCoords={setCoords} onSubmit={handleSaveSite} onCancel={closeSiteModal} />
            </Modal>
        </div>
    );
};

const SiteCard: React.FC<{ site: Site, onEdit: () => void, onDelete: () => void }> = ({ site, onEdit, onDelete }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    return (
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="p-4 flex justify-between items-center cursor-pointer hover:bg-slate-50" onClick={() => setIsExpanded(!isExpanded)}>
                <div className="flex items-center gap-4">
                    <Globe size={24} className="text-cyan-600"/>
                    <div>
                        <h3 className="font-bold text-lg text-slate-800">{site.name}</h3>
                        <p className="text-sm text-slate-500 flex items-center gap-1"><MapPin size={12}/>{site.location}</p>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${site.isDeleted ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                        {site.isDeleted ? 'Deleted' : 'Active'}
                    </span>
                    <button onClick={(e) => { e.stopPropagation(); onEdit(); }} className="p-2 text-slate-500 hover:text-blue-600"><Edit size={16}/></button>
                    <button onClick={(e) => { e.stopPropagation(); onDelete(); }} className={`p-2 ${site.isDeleted ? 'text-green-500 hover:text-green-700' : 'text-red-500 hover:text-red-700'}`}>
                        {site.isDeleted ? <RotateCcw size={16}/> : <Trash2 size={16}/>}
                    </button>
                    <ChevronDown size={20} className={`text-slate-500 transition-transform ${isExpanded ? 'rotate-180' : ''}`}/>
                </div>
            </div>
            {isExpanded && !site.isDeleted && <SiteDetailView site={site}/>}
        </div>
    )
}

const SiteDetailView: React.FC<{ site: Site }> = ({ site }) => {
    const [activeTab, setActiveTab] = useState<'ponds'|'inventory' | 'bookkeeping'>('ponds');
    return (
        <div className="border-t">
            <div className="px-4 border-b border-slate-200 flex">
                <TabButton active={activeTab === 'ponds'} onClick={() => setActiveTab('ponds')}><Droplets size={16}/>Ponds</TabButton>
                <TabButton active={activeTab === 'inventory'} onClick={() => setActiveTab('inventory')}><Archive size={16}/>Inventory</TabButton>
                <TabButton active={activeTab === 'bookkeeping'} onClick={() => setActiveTab('bookkeeping')}><Wallet size={16}/>Bookkeeping</TabButton>
            </div>
            <div className="p-4">
                {activeTab === 'ponds' && <PondsForSite site={site} />}
                {activeTab === 'inventory' && <InventoryForSite site={site} />}
                {activeTab === 'bookkeeping' && <BookkeepingForSite site={site} />}
            </div>
        </div>
    )
}


const PondsForSite: React.FC<{ site: Site }> = ({ site }) => {
    const { ponds, addPond, updatePond, deletePond } = useData();
    const navigate = useNavigate();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentPond, setCurrentPond] = useState<Partial<Pond> | null>(null);

    const sitePonds = useMemo(() => ponds.filter(p => p.siteId === site.id), [ponds, site.id]);

    const openModal = (pond: Partial<Pond> | null = null) => {
        if (pond) {
            setCurrentPond({ ...pond });
        } else {
            setCurrentPond({ name: '', siteId: site.id, stock: [], stockingDate: new Date().toISOString().split('T')[0] });
        }
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setCurrentPond(null);
    };

    const handleDelete = (id: number) => {
        if(window.confirm('Are you sure you want to delete this pond? This action cannot be undone.')) {
            deletePond(id);
        }
    };

    const totalStockCount = (pond: Pond) => pond.stock.reduce((sum, s) => sum + s.count, 0);

    return (
        <div className="space-y-4">
             <div className="flex justify-end gap-2">
                <button onClick={() => openModal()} className="btn-primary"><PlusCircle size={16}/>Add Pond</button>
            </div>
            <div className="overflow-x-auto">
                 <table className="w-full text-sm">
                    <thead className="text-xs text-slate-700 uppercase bg-slate-100">
                        <tr>
                            <th className="px-4 py-2">Name</th>
                            <th className="px-4 py-2">Species</th>
                            <th className="px-4 py-2">Stock Count</th>
                            <th className="px-4 py-2">Status</th>
                            <th className="px-4 py-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {sitePonds.map(pond => (
                           <tr key={pond.id} className="border-b hover:bg-slate-50 cursor-pointer" onClick={() => navigate(`/ponds/${pond.id}`)}>
                                <td className="px-4 py-2 font-medium text-slate-900">{pond.name}</td>
                                <td className="px-4 py-2 text-slate-600 truncate max-w-xs">{pond.stock.map(s => s.species).join(', ')}</td>
                                <td className="px-4 py-2 text-slate-600">{totalStockCount(pond).toLocaleString()}</td>
                                <td className="px-4 py-2 text-slate-600">
                                     <span className={`px-2 py-1 text-xs font-medium rounded-full ${pond.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>{pond.status}</span>
                                </td>
                                <td className="px-4 py-2" onClick={e => e.stopPropagation()}>
                                    <div className="flex items-center gap-2">
                                        <button onClick={() => openModal(pond)} className="p-1 text-slate-500 hover:text-blue-600"><Edit size={16}/></button>
                                        <button onClick={() => handleDelete(pond.id)} className="p-1 text-slate-500 hover:text-red-600"><Trash2 size={16}/></button>
                                        <ChevronRight size={18} className="text-slate-400" />
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {sitePonds.length === 0 && <p className="text-center text-slate-500 py-6">No ponds at this site.</p>}
            </div>
            {currentPond && (
                <Modal isOpen={isModalOpen} onClose={closeModal} title={currentPond?.id ? 'Edit Pond' : 'Add New Pond'}>
                    <PondForm site={site} currentPond={currentPond} addPond={addPond} updatePond={updatePond} closeModal={closeModal} />
                </Modal>
            )}
             <style>{`
                .btn-primary { display:inline-flex; align-items:center; gap:0.5rem; padding: 0.5rem 1rem; background-color: #0891b2; color: white; border-radius: 0.375rem; }
                .btn-secondary { display:inline-flex; align-items:center; gap:0.5rem; padding: 0.5rem 1rem; background-color: #f1f5f9; color: #334155; border-radius: 0.375rem; }
            `}</style>
        </div>
    )
}

const PondForm: React.FC<{ site: Site, currentPond: Partial<Pond>, addPond: (p: any) => void, updatePond: (p: any) => void, closeModal: () => void }> = ({ site, currentPond, addPond, updatePond, closeModal }) => {
    const [selectedCulture, setSelectedCulture] = useState<CultureType>(currentPond.cultureType || '🐟 Fresh Water Fish');
    const [localStock, setLocalStock] = useState<{ species: string; count: number; initialABW: number; }[]>(currentPond.stock || []);
    const [formError, setFormError] = useState('');

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        setFormError('');
        const form = e.target as HTMLFormElement;
        const formData = new FormData(form);
        
        const filteredStock = localStock.filter(s => s.count > 0);
        if(filteredStock.length === 0) {
            setFormError('Please add at least one species with a stock count greater than 0.');
            return;
        }

        const pondData: Omit<Pond, 'id' | 'status'> = {
            name: formData.get('name') as string,
            siteId: site.id,
            cultureType: formData.get('cultureType') as CultureType,
            stock: filteredStock,
            stockingDate: formData.get('stockingDate') as string,
        };

        if (currentPond?.id) {
            updatePond({ ...pondData, id: currentPond.id, status: currentPond.status || 'Active' });
        } else {
            addPond(pondData);
        }
        closeModal();
    };

    const handleSpeciesToggle = (species: string, isChecked: boolean) => {
        setLocalStock(prev => {
            if (isChecked) {
                return [...prev, { species, count: 0, initialABW: 0 }];
            } else {
                return prev.filter(s => s.species !== species);
            }
        });
    };
    
    const handleStockChange = (species: string, field: 'count' | 'initialABW', value: number) => {
        setLocalStock(prev => prev.map(s => s.species === species ? { ...s, [field]: value } : s));
    };
    
    useEffect(() => {
        setLocalStock([]);
    }, [selectedCulture]);

    const speciesOptions = CULTURE_SPECIES_MAP[selectedCulture] || [];

    return (
        <form onSubmit={handleSave} className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-3">
            <div className="md:col-span-2"><label>Pond Name</label><input name="name" type="text" defaultValue={currentPond?.name || ''} className="form-input" required /></div>
            <div className="md:col-span-2"><label>Site</label><input value={site.name} className="form-input" disabled /></div>
            <div><label>Stocking Date</label><input name="stockingDate" type="date" defaultValue={currentPond?.stockingDate || new Date().toISOString().split('T')[0]} className="form-input" required /></div>
            
            <div><label>Culture Type</label><select name="cultureType" value={selectedCulture} onChange={e => setSelectedCulture(e.target.value as CultureType)} className="form-input form-select">{Object.keys(CULTURE_SPECIES_MAP).map(type => <option key={type} value={type}>{type}</option>)}</select></div>
            
            <div className="md:col-span-2">
                <label>Species Selection</label>
                <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-2 p-3 bg-slate-50 rounded-md max-h-40 overflow-y-auto border">
                    {speciesOptions.map(species => (
                        <label key={species} className="flex items-center space-x-2 text-sm cursor-pointer">
                            <input
                                type="checkbox"
                                className="form-checkbox"
                                checked={localStock.some(s => s.species === species)}
                                onChange={(e) => handleSpeciesToggle(species, e.target.checked)}
                            />
                            <span>{species}</span>
                        </label>
                    ))}
                </div>
            </div>

            {localStock.length > 0 && (
                <div className="md:col-span-2 mt-2 space-y-4 p-3 bg-slate-50 rounded-md border">
                    <h4 className="font-medium text-slate-700 border-b pb-2 mb-3">Stock Details</h4>
                    {localStock.map((stockItem) => (
                        <div key={stockItem.species} className="grid grid-cols-3 gap-3 items-center">
                            <span className="font-medium text-sm truncate">{stockItem.species}</span>
                            <div>
                                <label className="text-xs text-slate-600">Count</label>
                                <input
                                    type="number"
                                    className="form-input text-sm p-1.5"
                                    value={stockItem.count}
                                    onChange={(e) => handleStockChange(stockItem.species, 'count', parseInt(e.target.value) || 0)}
                                />
                            </div>
                             <div>
                                <label className="text-xs text-slate-600">Initial ABW (g)</label>
                                <input
                                    type="number"
                                    step="0.1"
                                    className="form-input text-sm p-1.5"
                                    value={stockItem.initialABW}
                                    onChange={(e) => handleStockChange(stockItem.species, 'initialABW', parseFloat(e.target.value) || 0)}
                                />
                            </div>
                        </div>
                    ))}
                </div>
            )}
            
            {formError && <p className="md:col-span-2 text-sm text-red-600 bg-red-50 p-3 rounded-md">{formError}</p>}
            
            <div className="md:col-span-2 flex justify-end pt-4 mt-2 border-t">
                <button type="button" onClick={closeModal} className="btn-secondary">Cancel</button>
                <button type="submit" className="ml-3 px-4 py-2 text-sm font-medium text-white bg-cyan-600 border border-transparent rounded-md shadow-sm hover:bg-cyan-700">Save</button>
            </div>
             <style>{`
                label { display: block; margin-bottom: 0.25rem; font-size: 0.875rem; font-weight: 500; color: #475569; }
                .btn-secondary { display:inline-flex; align-items:center; gap:0.5rem; padding: 0.5rem 1rem; background-color: #f1f5f9; color: #334155; border-radius: 0.375rem; }
            `}</style>
        </form>
    )
}

const InventoryForSite: React.FC<{ site: Site }> = ({ site }) => {
    const { inventory, addInventoryItem, updateInventoryItem, deleteInventoryItem, transferInventoryItem } = useData();
    const [isAddEditModalOpen, setAddEditModalOpen] = useState(false);
    const [isTransferModalOpen, setTransferModalOpen] = useState(false);
    const [currentItem, setCurrentItem] = useState<Partial<InventoryItem> | null>(null);

    const siteInventory = useMemo(() => inventory.filter(i => i.siteId === site.id), [inventory, site.id]);

    const openAddEditModal = (item: Partial<InventoryItem> | null = null) => {
        setCurrentItem(item ? {...item} : { name: '', category: 'Feed', quantity: 0, unit: '', lowStockThreshold: 0, siteId: site.id });
        setAddEditModalOpen(true);
    };

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        const formData = new FormData(e.target as HTMLFormElement);
        const itemData = {
            name: formData.get('name') as string,
            category: formData.get('category') as InventoryItem['category'],
            quantity: parseFloat(formData.get('quantity') as string),
            unit: formData.get('unit') as string,
            lowStockThreshold: parseFloat(formData.get('lowStockThreshold') as string),
            siteId: site.id,
        };
        if (currentItem?.id) {
            updateInventoryItem({ id: currentItem.id, ...itemData });
        } else {
            addInventoryItem(itemData);
        }
        setAddEditModalOpen(false);
        setCurrentItem(null);
    };

    const handleDelete = (id: number) => {
        if(window.confirm('Are you sure?')) deleteInventoryItem(id);
    };
    
    const handleTransfer = (e: React.FormEvent) => {
        e.preventDefault();
        const formData = new FormData(e.target as HTMLFormElement);
        transferInventoryItem(
            parseInt(formData.get('fromSiteId') as string),
            parseInt(formData.get('toSiteId') as string),
            parseInt(formData.get('itemId') as string),
            parseFloat(formData.get('quantity') as string)
        );
        setTransferModalOpen(false);
    };
    
    const CategoryIcon = ({ category }: { category: string }) => {
        switch(category) {
            case 'Feed': return <Package className="text-orange-500"/>;
            case 'Feed Supplements': return <Beaker className="text-indigo-500"/>;
            case 'Pond Supplements': return <Beaker className="text-purple-500"/>;
            default: return <Package className="text-slate-500"/>;
        }
    }

    return (
        <div className="space-y-4">
            <div className="flex justify-end gap-2">
                <button onClick={() => setTransferModalOpen(true)} className="btn-secondary"><GitCommit size={16}/>Transfer</button>
                <button onClick={() => openAddEditModal()} className="btn-primary"><PlusCircle size={16}/>Add Item</button>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-sm">
                    <thead className="text-xs text-slate-700 uppercase bg-slate-100">
                        <tr><th className="px-4 py-2">Item</th><th className="px-4 py-2">Category</th><th className="px-4 py-2">Quantity</th><th className="px-4 py-2">Actions</th></tr>
                    </thead>
                    <tbody>
                        {siteInventory.map(item => (
                            <tr key={item.id} className="border-b hover:bg-slate-50">
                                <td className="px-4 py-2 font-medium text-slate-900 flex items-center gap-2"><CategoryIcon category={item.category} />{item.name}</td>
                                <td className="px-4 py-2 text-slate-600">{item.category}</td>
                                <td className={`px-4 py-2 font-semibold ${item.quantity <= item.lowStockThreshold ? 'text-red-500' : ''}`}>
                                    {item.quantity <= item.lowStockThreshold && <AlertTriangle size={14} className="inline mr-1"/>}
                                    {item.quantity} {item.unit}
                                </td>
                                <td className="px-4 py-2 flex items-center gap-2">
                                    <button onClick={() => openAddEditModal(item)} className="p-1 text-slate-500 hover:text-blue-600"><Edit size={16}/></button>
                                    <button onClick={() => handleDelete(item.id)} className="p-1 text-slate-500 hover:text-red-600"><Trash2 size={16}/></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {siteInventory.length === 0 && <p className="text-center text-slate-500 py-6">No inventory items at this site.</p>}
            </div>
            
            <Modal isOpen={isAddEditModalOpen} onClose={() => setAddEditModalOpen(false)} title={currentItem?.id ? 'Edit Item' : 'Add New Item'}>
                 <form onSubmit={handleSave} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2"><label>Item Name</label><input name="name" type="text" defaultValue={currentItem?.name || ''} className="form-input" required /></div>
                    <div><label>Category</label><select name="category" defaultValue={currentItem?.category || 'Feed'} className="form-input form-select"><option>Feed</option><option>Feed Supplements</option><option>Pond Supplements</option></select></div>
                    <div><label>Unit</label><input name="unit" type="text" defaultValue={currentItem?.unit || ''} className="form-input" placeholder="e.g., kg, pcs" required /></div>
                    <div><label>Quantity</label><input name="quantity" type="number" defaultValue={currentItem?.quantity ?? 0} className="form-input" required/></div>
                    <div><label>Low Stock Threshold</label><input name="lowStockThreshold" type="number" defaultValue={currentItem?.lowStockThreshold ?? 0} className="form-input" /></div>
                    <div className="md:col-span-2 flex justify-end pt-4"><button type="button" onClick={() => setAddEditModalOpen(false)} className="btn-secondary">Cancel</button><button type="submit" className="btn-primary ml-3">Save Item</button></div>
                </form>
            </Modal>
             <Modal isOpen={isTransferModalOpen} onClose={() => setTransferModalOpen(false)} title="Transfer Inventory Item">
                <TransferModalContent site={site} onSubmit={handleTransfer} onCancel={() => setTransferModalOpen(false)} />
            </Modal>
            <style>{`
                label { display: block; margin-bottom: 0.25rem; font-size: 0.875rem; font-weight: 500; color: #475569; }
                .btn-primary { display:inline-flex; align-items:center; gap:0.5rem; padding: 0.5rem 1rem; background-color: #0891b2; color: white; border-radius: 0.375rem; }
                .btn-secondary { display:inline-flex; align-items:center; gap:0.5rem; padding: 0.5rem 1rem; background-color: #f1f5f9; color: #334155; border-radius: 0.375rem; }
            `}</style>
        </div>
    )
}

const BookkeepingForSite: React.FC<{ site: Site }> = ({ site }) => {
    const { transactions, addTransaction, deleteTransaction, getFinancialSummaryForSite } = useData();
    const [isModalOpen, setIsModalOpen] = useState(false);

    const siteTransactions = useMemo(() => transactions.filter(t => t.siteId === site.id), [transactions, site.id]);
    const summary = useMemo(() => getFinancialSummaryForSite(site.id), [site.id, getFinancialSummaryForSite]);

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        const formData = new FormData(e.target as HTMLFormElement);
        addTransaction({
            type: formData.get('type') as 'income' | 'expense',
            description: formData.get('description') as string,
            amount: parseFloat(formData.get('amount') as string),
            siteId: site.id,
            date: formData.get('date') as string,
        });
        setIsModalOpen(false);
    };

    const handleDelete = (id: number) => {
        if(window.confirm('Are you sure?')) deleteTransaction(id);
    };

    return (
        <div className="space-y-4">
             <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-green-50 p-4 rounded-lg"><p className="text-sm text-green-700">Income</p><p className="text-2xl font-bold text-green-600">${summary.totalIncome.toFixed(2)}</p></div>
                <div className="bg-red-50 p-4 rounded-lg"><p className="text-sm text-red-700">Expense</p><p className="text-2xl font-bold text-red-600">${summary.totalExpense.toFixed(2)}</p></div>
                <div className="bg-blue-50 p-4 rounded-lg"><p className="text-sm text-blue-700">Net Profit</p><p className="text-2xl font-bold text-blue-600">${summary.netProfit.toFixed(2)}</p></div>
            </div>
            <div className="flex justify-end"><button onClick={() => setIsModalOpen(true)} className="btn-primary"><PlusCircle size={16}/>Add Transaction</button></div>
            <div className="overflow-x-auto">
                 <table className="w-full text-sm">
                    <thead className="text-xs text-slate-700 uppercase bg-slate-100">
                        <tr><th className="px-4 py-2">Date</th><th className="px-4 py-2">Description</th><th className="px-4 py-2">Amount</th><th className="px-4 py-2">Action</th></tr>
                    </thead>
                    <tbody>
                        {siteTransactions.map(t => (
                            <tr key={t.id} className="border-b hover:bg-slate-50">
                                <td className="px-4 py-2 text-slate-600">{new Date(t.date).toLocaleDateString()}</td>
                                <td className="px-4 py-2 font-medium text-slate-900">{t.description}</td>
                                <td className={`px-4 py-2 font-semibold ${t.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>{t.type === 'income' ? '+' : '-'}${t.amount.toFixed(2)}</td>
                                <td className="px-4 py-2"><button onClick={() => handleDelete(t.id)} className="p-1 text-slate-500 hover:text-red-600"><Trash2 size={16}/></button></td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {siteTransactions.length === 0 && <p className="text-center text-slate-500 py-6">No transactions for this site.</p>}
            </div>
             <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={`Add Transaction for ${site.name}`}>
                <form onSubmit={handleSave} className="space-y-4">
                    <div><label>Type</label><select name="type" className="form-input form-select"><option value="income">Income</option><option value="expense">Expense</option></select></div>
                    <div><label>Date</label><input name="date" type="date" defaultValue={new Date().toISOString().split('T')[0]} className="form-input" required /></div>
                    <div><label>Description</label><input name="description" type="text" placeholder="e.g., Sale of fish" className="form-input" required /></div>
                    <div><label>Amount ($)</label><input name="amount" type="number" step="0.01" placeholder="100.00" className="form-input" required /></div>
                    <div className="flex justify-end pt-4"><button type="button" onClick={() => setIsModalOpen(false)} className="btn-secondary">Cancel</button><button type="submit" className="btn-primary ml-3">Save</button></div>
                </form>
            </Modal>
        </div>
    )
}

const SiteForm: React.FC<{ currentSite: Partial<Site> | null; coords: {lat:number, lng:number}; setCoords: React.Dispatch<React.SetStateAction<{lat: number,lng: number}>>; onSubmit: (e: React.FormEvent) => void; onCancel: () => void; }> = ({ currentSite, coords, setCoords, onSubmit, onCancel }) => (
    <form onSubmit={onSubmit} className="space-y-4">
        <div><label>Site Name</label><input name="name" type="text" defaultValue={currentSite?.name || ''} className="form-input" required/></div>
        <div><label>Location</label><input name="location" type="text" defaultValue={currentSite?.location || ''} className="form-input"/></div>
        <div>
            <label>Geolocation</label>
            <div className="w-full h-32 bg-slate-200 rounded-md relative overflow-hidden mt-1">
                <div className="absolute inset-0 bg-repeat bg-center" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%2394a3b8' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")` }}></div>
                {coords.lat !== 0 && coords.lng !== 0 && <div style={{position:'absolute',left:'50%',top:'50%',transform:'translate(-50%,-50%)'}}><MapPin className="text-red-500" size={32} /></div>}
            </div>
            <div className="grid grid-cols-2 gap-4 mt-2">
                <div><label className="text-xs">Latitude</label><input name="lat" type="number" step="any" value={coords.lat} onChange={e => setCoords({...coords, lat: parseFloat(e.target.value) || 0})} className="form-input" /></div>
                <div><label className="text-xs">Longitude</label><input name="lng" type="number" step="any" value={coords.lng} onChange={e => setCoords({...coords, lng: parseFloat(e.target.value) || 0})} className="form-input" /></div>
            </div>
        </div>
        <div className="flex justify-end pt-4"><button type="button" onClick={onCancel} className="btn-secondary">Cancel</button><button type="submit" className="btn-primary ml-3">Save</button></div>
    </form>
);

const TransferModalContent: React.FC<{ site: Site; onSubmit: (e: React.FormEvent) => void; onCancel: () => void; }> = ({ site, onSubmit, onCancel }) => {
    const { sites, inventory } = useData();
    const [toSiteId, setToSiteId] = useState<number | undefined>(sites.filter(s => !s.isDeleted && s.id !== site.id)[0]?.id);
    const [selectedItemId, setSelectedItemId] = useState<number | undefined>();

    const availableItems = useMemo(() => inventory.filter(item => item.siteId === site.id && item.quantity > 0), [site, inventory]);
    const selectedItem = inventory.find(i => i.id === selectedItemId);

    return (
        <form onSubmit={onSubmit} className="space-y-4">
            <input type="hidden" name="fromSiteId" value={site.id} />
            <div><label>From Site</label><input value={site.name} className="form-input" disabled/></div>
            <div><label>To Site</label><select name="toSiteId" value={toSiteId} onChange={e => setToSiteId(Number(e.target.value))} className="form-input form-select">{sites.filter(s => !s.isDeleted && s.id !== site.id).map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
            <div><label>Item</label><select name="itemId" value={selectedItemId} onChange={e => setSelectedItemId(Number(e.target.value))} className="form-input form-select"><option value="">-- Select --</option>{availableItems.map(item => <option key={item.id} value={item.id}>{item.name} ({item.quantity} available)</option>)}</select></div>
            <div><label>Quantity</label><input name="quantity" type="number" min="0.01" max={selectedItem?.quantity} step="any" className="form-input" required disabled={!selectedItemId} /></div>
            <div className="flex justify-end pt-4"><button type="button" onClick={onCancel} className="btn-secondary">Cancel</button><button type="submit" className="btn-primary ml-3" disabled={!toSiteId || !selectedItemId}>Confirm</button></div>
        </form>
    );
};

export default Sites;