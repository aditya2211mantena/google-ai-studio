
import React, { useState } from 'react';
import { Users, UserPlus, ChevronsRight } from 'lucide-react';
import type { User, Site } from '../types';
import Modal from './Modal';
import { useData } from '../contexts/DataContext';


const Supervisors: React.FC = () => {
    const { sites, supervisors, supervisorAssignments, updateSupervisorAssignments } = useData();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedSupervisor, setSelectedSupervisor] = useState<User | null>(null);

    const openModal = (supervisor: User) => {
        setSelectedSupervisor(supervisor);
        setIsModalOpen(true);
    };
    const closeModal = () => {
        setIsModalOpen(false);
        setSelectedSupervisor(null);
    };

    const handleSaveAssignment = (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedSupervisor) return;
        
        const form = e.target as HTMLFormElement;
        const formData = new FormData(form);
        const assignedSiteIds = Array.from(formData.getAll('sites')).map(Number);
        
        updateSupervisorAssignments(selectedSupervisor.id, assignedSiteIds);
        closeModal();
    };

    return (
        <div className="space-y-6">
            <header>
                <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Supervisor Management</h1>
                <p className="text-slate-500 mt-1">Assign supervisors to manage specific sites.</p>
            </header>
            
            <div className="bg-white p-4 md:p-6 rounded-xl shadow-md">
                <div className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-4">
                    <h3 className="text-lg font-semibold text-slate-800">All Supervisors</h3>
                    <button className="bg-cyan-600 text-white px-4 py-2 rounded-md hover:bg-cyan-700 flex items-center justify-center">
                        <UserPlus size={16} className="mr-2"/> Add Supervisor
                    </button>
                </div>
                <div className="space-y-4">
                    {supervisors.map(supervisor => (
                        <div key={supervisor.id} className="p-4 border rounded-lg flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 hover:bg-slate-50">
                            <div>
                                <h4 className="font-semibold text-slate-800">{supervisor.name}</h4>
                                <p className="text-sm text-slate-500">{supervisor.email}</p>
                            </div>
                            <div className="flex items-center gap-4 w-full sm:w-auto">
                                <div className="flex-1">
                                    <h5 className="text-sm font-medium text-slate-600 sm:text-right">Assigned Sites</h5>
                                    <div className="flex flex-wrap gap-1 mt-1 sm:justify-end">
                                        {(supervisorAssignments[supervisor.id] || []).length > 0 ? (
                                            (supervisorAssignments[supervisor.id] || []).map(siteId => (
                                                <span key={siteId} className="px-2 py-1 text-xs font-medium rounded-full bg-cyan-100 text-cyan-800">
                                                    {sites.find(s => s.id === siteId)?.name || 'N/A'}
                                                </span>
                                            ))
                                        ) : (
                                             <span className="text-xs text-slate-400">None</span>
                                        )}
                                    </div>
                                </div>
                                <button onClick={() => openModal(supervisor)} className="p-2 text-slate-500 rounded-full hover:bg-slate-100"><ChevronsRight size={20}/></button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {selectedSupervisor && (
                <Modal isOpen={isModalOpen} onClose={closeModal} title={`Assign Sites for ${selectedSupervisor.name}`}>
                    <form onSubmit={handleSaveAssignment}>
                        <div className="space-y-2">
                            <p className="font-medium text-slate-700">Select sites to assign:</p>
                            {sites.filter(s => !s.isDeleted).map(site => (
                                <label key={site.id} className="flex items-center p-3 space-x-3 bg-slate-50 rounded-md hover:bg-slate-100">
                                    <input 
                                        type="checkbox" 
                                        name="sites" 
                                        value={site.id} 
                                        defaultChecked={(supervisorAssignments[selectedSupervisor.id] || []).includes(site.id)}
                                        className="form-checkbox"
                                    />
                                    <span className="text-sm text-gray-700">{site.name}</span>
                                </label>
                            ))}
                        </div>
                        <div className="flex justify-end pt-6">
                            <button type="button" onClick={closeModal} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 border border-transparent rounded-md hover:bg-slate-200">Cancel</button>
                            <button type="submit" className="ml-3 px-4 py-2 text-sm font-medium text-white bg-cyan-600 border border-transparent rounded-md shadow-sm hover:bg-cyan-700">Save Assignments</button>
                        </div>
                    </form>
                </Modal>
            )}
        </div>
    );
};

export default Supervisors;
