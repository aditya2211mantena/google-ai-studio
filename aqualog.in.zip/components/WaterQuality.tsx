
import React from 'react';

// This component is obsolete. Its functionality has been moved into PondDetail.tsx
const WaterQuality: React.FC = () => {
  return null;
};

export default WaterQuality;
