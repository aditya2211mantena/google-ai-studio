
import React, { createContext, useState, useContext } from 'react';
import type { User } from '../types';

// Mock user data to simulate a database
const mockUsers: User[] = [
    { id: 1, name: 'Admin User', email: 'admin@aqualog.in', role: 'admin' },
    { id: 2, name: 'Supervisor User', email: 'supervisor@aqualog.in', role: 'supervisor' },
    { id: 3, name: 'Farmer User', email: 'farmer@aqualog.in', role: 'farmer' },
];

interface AuthContextType {
  user: User | null;
  login: (email: string) => User | null;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    try {
        const savedUser = localStorage.getItem('aqualog-user');
        return savedUser ? JSON.parse(savedUser) : null;
    } catch (error) {
        console.error("Failed to parse user from localStorage", error);
        return null;
    }
  });

  const login = (email: string): User | null => {
    const foundUser = mockUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (foundUser) {
      localStorage.setItem('aqualog-user', JSON.stringify(foundUser));
      setUser(foundUser);
      return foundUser;
    }
    return null;
  };

  const logout = () => {
    localStorage.removeItem('aqualog-user');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
