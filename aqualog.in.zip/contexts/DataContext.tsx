
import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import type { Site, Pond, WaterQualityReading, FeedingEvent, MortalityLog, HarvestLog, InventoryItem, Transaction, ABWLog, ApplicationLog, User, PondEvent, HarvestType } from '../types';

// Initial Mock Data
import { 
    initialSites, initialPonds, initialWaterReadings, initialFeedingEvents, 
    initialMortalityLogs, initialHarvestLogs, initialInventory, initialTransactions,
    initialABWLogs, initialApplicationLogs, mockUsers, initialSupervisorAssignments,
    generateRandomPonds, generateRandomLogs
} from '../data/mockData';

// Helper to safely get item from localStorage
function getInitialState<T>(key: string, initialValue: T): T {
    try {
        const item = window.localStorage.getItem(key);
        // if item exists, parse it, otherwise return initial value
        return item ? JSON.parse(item) : initialValue;
    } catch (error) {
        console.warn(`Error reading localStorage key "${key}":`, error);
        return initialValue;
    }
}

interface FinancialSummary {
    totalIncome: number;
    totalExpense: number;
    netProfit: number;
}

interface DataContextType {
    // State
    sites: Site[];
    ponds: Pond[];
    waterReadings: WaterQualityReading[];
    feedingEvents: FeedingEvent[];
    mortalityLogs: MortalityLog[];
    harvestLogs: HarvestLog[];
    inventory: InventoryItem[];
    transactions: Transaction[];
    abwLogs: ABWLog[];
    applicationLogs: ApplicationLog[];
    supervisors: User[];
    supervisorAssignments: { [userId: number]: number[] };

    // Methods
    addSite: (site: Omit<Site, 'id' | 'isDeleted'>) => void;
    updateSite: (site: Site) => void;
    toggleSiteDeleted: (id: number) => void;

    addPond: (pond: Omit<Pond, 'id' | 'status'>) => void;
    updatePond: (pond: Pond) => void;
    deletePond: (id: number) => void;

    addWaterReading: (reading: Omit<WaterQualityReading, 'id'>) => void;
    deleteWaterReading: (id: number) => void;

    addFeedingEvent: (event: Omit<FeedingEvent, 'id'>) => void;
    deleteFeedingEvent: (id: number) => void;
    
    addMortalityLogs: (logs: Omit<MortalityLog, 'id' | 'previousStock' | 'newStock' | 'newBiomass'>[], pondId: number, recordedById: number) => void;
    deleteMortalityLog: (id: number) => void;

    addHarvestLogs: (logs: Omit<HarvestLog, 'id' | 'abw' | 'value' | 'transactionId'>[]) => void;
    deleteHarvestLog: (id: number) => void;

    addInventoryItem: (item: Omit<InventoryItem, 'id'>) => void;
    updateInventoryItem: (item: InventoryItem) => void;
    deleteInventoryItem: (id: number) => void;
    transferInventoryItem: (fromSiteId: number, toSiteId: number, itemId: number, quantity: number) => void;

    addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
    deleteTransaction: (id: number) => void;
    
    addABWLogs: (logs: Omit<ABWLog, 'id'>[]) => void;
    deleteABWLog: (id: number) => void;

    addApplicationLogs: (logs: Omit<ApplicationLog, 'id' | 'siteId' | 'productName' | 'category' | 'unit' | 'transactionId'>[]) => void;
    deleteApplicationLog: (id: number) => void;
    
    updateSupervisorAssignments: (userId: number, siteIds: number[]) => void;
    getAllEventsForPond: (pondId: number) => PondEvent[];
    getFinancialSummaryForSite: (siteId: number) => FinancialSummary;
    seedSampleData: (type: 'ponds' | 'logs') => void;
    resetAllData: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [sites, setSites] = useState<Site[]>(() => getInitialState('aqualog-sites', initialSites));
    useEffect(() => { localStorage.setItem('aqualog-sites', JSON.stringify(sites)); }, [sites]);

    const [ponds, setPonds] = useState<Pond[]>(() => getInitialState('aqualog-ponds', initialPonds));
    useEffect(() => { localStorage.setItem('aqualog-ponds', JSON.stringify(ponds)); }, [ponds]);
    
    const [waterReadings, setWaterReadings] = useState<WaterQualityReading[]>(() => getInitialState('aqualog-waterReadings', initialWaterReadings));
    useEffect(() => { localStorage.setItem('aqualog-waterReadings', JSON.stringify(waterReadings)); }, [waterReadings]);

    const [feedingEvents, setFeedingEvents] = useState<FeedingEvent[]>(() => getInitialState('aqualog-feedingEvents', initialFeedingEvents));
    useEffect(() => { localStorage.setItem('aqualog-feedingEvents', JSON.stringify(feedingEvents)); }, [feedingEvents]);

    const [mortalityLogs, setMortalityLogs] = useState<MortalityLog[]>(() => getInitialState('aqualog-mortalityLogs', initialMortalityLogs));
    useEffect(() => { localStorage.setItem('aqualog-mortalityLogs', JSON.stringify(mortalityLogs)); }, [mortalityLogs]);
    
    const [harvestLogs, setHarvestLogs] = useState<HarvestLog[]>(() => getInitialState('aqualog-harvestLogs', initialHarvestLogs));
    useEffect(() => { localStorage.setItem('aqualog-harvestLogs', JSON.stringify(harvestLogs)); }, [harvestLogs]);
    
    const [inventory, setInventory] = useState<InventoryItem[]>(() => getInitialState('aqualog-inventory', initialInventory));
    useEffect(() => { localStorage.setItem('aqualog-inventory', JSON.stringify(inventory)); }, [inventory]);
    
    const [transactions, setTransactions] = useState<Transaction[]>(() => getInitialState('aqualog-transactions', initialTransactions));
    useEffect(() => { localStorage.setItem('aqualog-transactions', JSON.stringify(transactions)); }, [transactions]);

    const [abwLogs, setABWLogs] = useState<ABWLog[]>(() => getInitialState('aqualog-abwLogs', initialABWLogs));
    useEffect(() => { localStorage.setItem('aqualog-abwLogs', JSON.stringify(abwLogs)); }, [abwLogs]);

    const [applicationLogs, setApplicationLogs] = useState<ApplicationLog[]>(() => getInitialState('aqualog-applicationLogs', initialApplicationLogs));
    useEffect(() => { localStorage.setItem('aqualog-applicationLogs', JSON.stringify(applicationLogs)); }, [applicationLogs]);

    const [supervisors] = useState<User[]>(mockUsers.filter(u => u.role === 'supervisor'));
    
    const [supervisorAssignments, setSupervisorAssignments] = useState<{ [userId: number]: number[] }>(() => getInitialState('aqualog-supervisorAssignments', initialSupervisorAssignments));
    useEffect(() => { localStorage.setItem('aqualog-supervisorAssignments', JSON.stringify(supervisorAssignments)); }, [supervisorAssignments]);

    // --- SITES ---
    const addSite = (site: Omit<Site, 'id' | 'isDeleted'>) => setSites(prev => [...prev, { id: Date.now(), ...site, isDeleted: false }]);
    const updateSite = (site: Site) => setSites(prev => prev.map(s => s.id === site.id ? site : s));
    const toggleSiteDeleted = (id: number) => setSites(prev => prev.map(s => s.id === id ? { ...s, isDeleted: !s.isDeleted } : s));

    // --- PONDS ---
    const addPond = (pond: Omit<Pond, 'id' | 'status'>) => setPonds(prev => [...prev, { id: Date.now(), ...pond, status: 'Active' }]);
    const updatePond = (pond: Pond) => setPonds(prev => prev.map(p => p.id === pond.id ? pond : p));
    const deletePond = (id: number) => setPonds(prev => prev.filter(p => p.id !== id));

    // --- WATER QUALITY ---
    const addWaterReading = (reading: Omit<WaterQualityReading, 'id'>) => setWaterReadings(prev => [{ id: Date.now(), ...reading }, ...prev].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    const deleteWaterReading = (id: number) => setWaterReadings(prev => prev.filter(r => r.id !== id));

    // --- FEEDING ---
    const addFeedingEvent = (event: Omit<FeedingEvent, 'id'>) => {
        const newEvent: FeedingEvent = {
            id: Date.now(),
            ...event
        };

        setFeedingEvents(prev => [newEvent, ...prev].sort((a,b) => new Date(b.time).getTime() - new Date(a.time).getTime()));
        
        setInventory(prev => {
            const newInventory = prev.map(item => ({ ...item }));
            const pond = ponds.find(p => p.id === event.pondId);
            if(!pond) return prev;

            const feedItemIndex = newInventory.findIndex(i => i.id === event.inventoryFeedId && i.siteId === pond.siteId);
            if (feedItemIndex > -1) {
                newInventory[feedItemIndex].quantity -= event.quantity;
            }

            event.supplements.forEach(supplement => {
                const supplementItemIndex = newInventory.findIndex(i => i.id === supplement.inventoryItemId && i.siteId === pond.siteId);
                if(supplementItemIndex > -1) {
                    newInventory[supplementItemIndex].quantity -= supplement.quantityUsed;
                }
            });

            return newInventory;
        });
    };
    const deleteFeedingEvent = (id: number) => {
        const eventToDelete = feedingEvents.find(e => e.id === id);
        if (!eventToDelete) return;
        
        setInventory(prev => {
            const newInventory = prev.map(item => ({ ...item }));
            const pond = ponds.find(p => p.id === eventToDelete.pondId);
            if(!pond) return prev;

            const feedItemIndex = newInventory.findIndex(i => i.id === eventToDelete.inventoryFeedId && i.siteId === pond.siteId);
            if (feedItemIndex > -1) {
                newInventory[feedItemIndex].quantity += eventToDelete.quantity;
            }

            eventToDelete.supplements.forEach(supplement => {
                const supplementItemIndex = newInventory.findIndex(i => i.id === supplement.inventoryItemId && i.siteId === pond.siteId);
                if(supplementItemIndex > -1) {
                    newInventory[supplementItemIndex].quantity += supplement.quantityUsed;
                }
            });
            
            return newInventory;
        });

        setFeedingEvents(prev => prev.filter(e => e.id !== id));
    };
    
    // --- MORTALITY ---
    const addMortalityLogs = (logs: Omit<MortalityLog, 'id' | 'previousStock' | 'newStock' | 'newBiomass'>[], pondId: number, recordedById: number) => {
        const newLogs: MortalityLog[] = [];
        
        setPonds(prevPonds => {
            const updatedPonds = JSON.parse(JSON.stringify(prevPonds));
            const pondToUpdate = updatedPonds.find((p: Pond) => p.id === pondId);
            if (!pondToUpdate) return prevPonds;
    
            logs.forEach((logEntry, index) => {
                const stockItem = pondToUpdate.stock.find((s: {species: string}) => s.species === logEntry.speciesName);
                if (!stockItem) return;
    
                const previousStock = stockItem.count;
                const newStock = previousStock - logEntry.mortality;
                const newBiomass = newStock * logEntry.abwAtEntry;
    
                const newLog: MortalityLog = {
                    id: Date.now() + index,
                    ...logEntry,
                    previousStock,
                    newStock,
                    newBiomass,
                    recordedById
                };
                newLogs.push(newLog);
    
                // Update the stock count in the pond object
                stockItem.count = newStock;
            });
            return updatedPonds;
        });

        if (newLogs.length > 0) {
            setMortalityLogs(prev => [...newLogs, ...prev].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
        }
    };

    const deleteMortalityLog = (id: number) => {
        const logToDelete = mortalityLogs.find(l => l.id === id);
        if (!logToDelete) return;

        setMortalityLogs(prev => prev.filter(l => l.id !== id));

        setPonds(prev => prev.map(pond => {
            if (pond.id === logToDelete.pondId) {
                const newStock = pond.stock.map(stockItem => {
                    if (stockItem.species === logToDelete.speciesName) {
                        // Revert the count to the state before this log was made
                        return { ...stockItem, count: logToDelete.previousStock };
                    }
                    return stockItem;
                });
                return { ...pond, stock: newStock };
            }
            return pond;
        }));
    };

    // --- HARVEST ---
    const addHarvestLogs = (logs: Omit<HarvestLog, 'id' | 'abw' | 'value' | 'transactionId'>[]) => {
        const newLogs: HarvestLog[] = [];
        const newTransactions: Transaction[] = [];

        setPonds(prevPonds => {
            const updatedPonds = JSON.parse(JSON.stringify(prevPonds));
            const firstLog = logs[0];
            if (!firstLog) return prevPonds;

            const pondToUpdate = updatedPonds.find((p: Pond) => p.id === firstLog.pondId);
            if (!pondToUpdate) return prevPonds;

            const isFullHarvest = firstLog.harvestType === 'Full';

            logs.forEach((logEntry, index) => {
                const abw = logEntry.numberHarvested > 0 ? logEntry.totalWeight / logEntry.numberHarvested : 0;
                const value = logEntry.costPerKg ? logEntry.totalWeight * logEntry.costPerKg : 0;
                const transactionId = value > 0 ? Date.now() + 1000 + index : undefined;

                newLogs.push({
                    id: Date.now() + index,
                    ...logEntry,
                    abw,
                    value,
                    transactionId,
                });

                if (value > 0 && transactionId) {
                    newTransactions.push({
                        id: transactionId,
                        type: 'income',
                        description: `${logEntry.harvestType} harvest of ${logEntry.speciesName} from ${pondToUpdate.name}`,
                        amount: value,
                        date: logEntry.date,
                        siteId: pondToUpdate.siteId,
                    });
                }

                if (!isFullHarvest) {
                    const stockItem = pondToUpdate.stock.find((s: {species: string}) => s.species === logEntry.speciesName);
                    if (stockItem) {
                        stockItem.count -= logEntry.numberHarvested;
                    }
                }
            });

            if (isFullHarvest) {
                pondToUpdate.status = 'Harvested';
                pondToUpdate.stock = [];
            }
            
            return updatedPonds;
        });

        setHarvestLogs(prev => [...prev, ...newLogs].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
        setTransactions(prev => [...prev, ...newTransactions].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    };

    const deleteHarvestLog = (id: number) => {
        const logToDelete = harvestLogs.find(l => l.id === id);
        if (!logToDelete) return;

        setHarvestLogs(prev => prev.filter(l => l.id !== id));

        if (logToDelete.transactionId) {
            setTransactions(prev => prev.filter(t => t.id !== logToDelete.transactionId));
        }

        if (logToDelete.harvestType === 'Partial') {
            setPonds(prev => prev.map(pond => {
                if (pond.id === logToDelete.pondId) {
                    const newStock = pond.stock.map(stockItem => {
                        if (stockItem.species === logToDelete.speciesName) {
                            return { ...stockItem, count: stockItem.count + logToDelete.numberHarvested };
                        }
                        return stockItem;
                    });
                    return { ...pond, stock: newStock };
                }
                return pond;
            }));
        }
    };


    // --- INVENTORY ---
    const addInventoryItem = (item: Omit<InventoryItem, 'id'>) => setInventory(prev => [...prev, { id: Date.now(), ...item }]);
    const updateInventoryItem = (item: InventoryItem) => setInventory(prev => prev.map(i => i.id === item.id ? item : i));
    const deleteInventoryItem = (id: number) => setInventory(prev => prev.filter(i => i.id !== id));
    const transferInventoryItem = (fromSiteId: number, toSiteId: number, itemId: number, quantity: number) => {
        setInventory(prev => {
            const newInventory = [...prev];
            const sourceItem = newInventory.find(i => i.id === itemId && i.siteId === fromSiteId);
            if (!sourceItem || sourceItem.quantity < quantity) {
                alert("Insufficient stock to transfer.");
                return prev; // Not enough stock
            }
            sourceItem.quantity -= quantity;

            let destItem = newInventory.find(i => i.name === sourceItem.name && i.unit === sourceItem.unit && i.siteId === toSiteId);
            if (destItem) {
                destItem.quantity += quantity;
            } else {
                destItem = { ...sourceItem, id: Date.now(), siteId: toSiteId, quantity: quantity };
                newInventory.push(destItem);
            }
            return newInventory;
        });
    };


    // --- TRANSACTIONS ---
    const addTransaction = (transaction: Omit<Transaction, 'id'>) => setTransactions(prev => [{ id: Date.now(), ...transaction }, ...prev].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    const deleteTransaction = (id: number) => setTransactions(prev => prev.filter(t => t.id !== id));

    // --- ABW ---
    const addABWLogs = (logs: Omit<ABWLog, 'id'>[]) => {
        const newLogs = logs.map((log, i) => ({ id: Date.now() + i, ...log }));
        setABWLogs(prev => [...prev, ...newLogs].sort((a,b) => new Date(b.samplingDate).getTime() - new Date(a.samplingDate).getTime()));
    };
    const deleteABWLog = (id: number) => setABWLogs(prev => prev.filter(l => l.id !== id));

    // --- APPLICATIONS ---
    const addApplicationLogs = (logs: Omit<ApplicationLog, 'id' | 'siteId' | 'productName' | 'category' | 'unit' | 'transactionId'>[]) => {
        const newLogs: ApplicationLog[] = [];
        const newTransactions: Transaction[] = [];

        setInventory(prevInventory => {
            const updatedInventory = JSON.parse(JSON.stringify(prevInventory));
            
            logs.forEach((logEntry, index) => {
                const pond = ponds.find(p => p.id === logEntry.pondId);
                if (!pond) return;

                const inventoryItem = updatedInventory.find((i: InventoryItem) => i.id === logEntry.inventoryItemId && i.siteId === pond.siteId);
                if (!inventoryItem || inventoryItem.quantity < logEntry.quantityUsed) {
                    alert(`Not enough stock for ${inventoryItem?.name || 'item'}. Available: ${inventoryItem?.quantity || 0}, Required: ${logEntry.quantityUsed}.`);
                    throw new Error("Insufficient stock");
                }

                inventoryItem.quantity -= logEntry.quantityUsed;

                const expense = (inventoryItem.pricePerUnit || 0) * logEntry.quantityUsed;
                let transactionId: number | undefined = undefined;

                if (expense > 0) {
                    transactionId = Date.now() + 1000 + index;
                    newTransactions.push({
                        id: transactionId,
                        type: 'expense',
                        description: `Application of ${inventoryItem.name} in ${pond.name}`,
                        amount: expense,
                        date: logEntry.date,
                        siteId: pond.siteId,
                    });
                }
                
                newLogs.push({
                    id: Date.now() + index,
                    ...logEntry,
                    siteId: pond.siteId,
                    productName: inventoryItem.name,
                    category: inventoryItem.category as 'Pond Supplements' | 'Feed Supplements',
                    unit: inventoryItem.unit,
                    transactionId,
                });
            });

            return updatedInventory;
        });
        
        if (newLogs.length > 0) {
            setApplicationLogs(prev => [...prev, ...newLogs].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
        }
        if (newTransactions.length > 0) {
            setTransactions(prev => [...prev, ...newTransactions].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
        }
    };

    const deleteApplicationLog = (id: number) => {
        const logToDelete = applicationLogs.find(l => l.id === id);
        if (!logToDelete) return;

        setInventory(prev => prev.map(item =>
            item.id === logToDelete.inventoryItemId && item.siteId === logToDelete.siteId
            ? { ...item, quantity: item.quantity + logToDelete.quantityUsed }
            : item
        ));
        
        if (logToDelete.transactionId) {
            setTransactions(prev => prev.filter(t => t.id !== logToDelete.transactionId));
        }

        setApplicationLogs(prev => prev.filter(l => l.id !== id));
    };

    // --- SUPERVISORS ---
    const updateSupervisorAssignments = (userId: number, siteIds: number[]) => {
        setSupervisorAssignments(prev => ({...prev, [userId]: siteIds }));
    }

    const getAllEventsForPond = (pondId: number): PondEvent[] => {
        const events: PondEvent[] = [];
        feedingEvents.filter(e => e.pondId === pondId).forEach(e => events.push({ ...e, type: 'feed' }));
        waterReadings.filter(r => r.pondId === pondId).forEach(r => events.push({ ...r, type: 'water' }));
        mortalityLogs.filter(l => l.pondId === pondId).forEach(l => events.push({ ...l, type: 'mortality' }));
        harvestLogs.filter(h => h.pondId === pondId).forEach(h => events.push({ ...h, type: 'harvest' }));
        abwLogs.filter(a => a.pondId === pondId).forEach(a => events.push({ ...a, type: 'abw' }));
        applicationLogs.filter(a => a.pondId === pondId).forEach(a => events.push({ ...a, type: 'application' }));
        
        return events.sort((a, b) => {
            let dateA: Date, dateB: Date;
            switch(a.type) {
                case 'feed': dateA = new Date(a.time); break;
                case 'water': dateA = new Date(a.date); break;
                case 'mortality': dateA = new Date(a.date); break;
                case 'harvest': dateA = new Date(a.date); break;
                case 'abw': dateA = new Date(a.samplingDate); break;
                case 'application': dateA = new Date(a.date); break;
                default: dateA = new Date();
            }
            switch(b.type) {
                case 'feed': dateB = new Date(b.time); break;
                case 'water': dateB = new Date(b.date); break;
                case 'mortality': dateB = new Date(b.date); break;
                case 'harvest': dateB = new Date(b.date); break;
                case 'abw': dateB = new Date(b.samplingDate); break;
                case 'application': dateB = new Date(b.date); break;
                default: dateB = new Date();
            }
            return dateB.getTime() - dateA.getTime();
        });
    };

    const getFinancialSummaryForSite = (siteId: number): FinancialSummary => {
        const siteTransactions = transactions.filter(t => t.siteId === siteId);
        const totalIncome = siteTransactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
        const totalExpense = siteTransactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
        return {
            totalIncome,
            totalExpense,
            netProfit: totalIncome - totalExpense
        };
    };
    
    // --- DEV TOOLS ---
    const seedSampleData = (type: 'ponds' | 'logs') => {
        if (type === 'ponds') {
            const newPonds = generateRandomPonds(3, sites);
            if (newPonds.length === 0) {
                alert('No active sites to add ponds to. Please add a site first.');
                return;
            }
            setPonds(prev => [...prev, ...newPonds]);
            alert('3 new sample ponds added!');
        } else if (type === 'logs') {
            const activePonds = ponds.filter(p => p.status === 'Active');
            if (activePonds.length === 0) {
                alert('No active ponds to add logs to. Please add a pond first.');
                return;
            }
            const { newWaterReadings, newFeedingEvents, newMortalityLogs } = generateRandomLogs(50, activePonds, inventory);
            setWaterReadings(prev => [...prev, ...newWaterReadings].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
            setFeedingEvents(prev => [...prev, ...newFeedingEvents].sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime()));
            setMortalityLogs(prev => [...prev, ...newMortalityLogs].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
            alert('50 new random log entries added to active ponds!');
        }
    };

    const resetAllData = () => {
        const keys = Object.keys(window.localStorage);
        for (let key of keys) {
            if (key.startsWith('aqualog-')) {
                window.localStorage.removeItem(key);
            }
        }
        window.location.reload();
    };

    const value = {
        sites, ponds, waterReadings, feedingEvents, mortalityLogs, harvestLogs, inventory, transactions, abwLogs, applicationLogs, supervisors, supervisorAssignments,
        addSite, updateSite, toggleSiteDeleted,
        addPond, updatePond, deletePond,
        addWaterReading, deleteWaterReading,
        addFeedingEvent, deleteFeedingEvent,
        addMortalityLogs, deleteMortalityLog,
        addHarvestLogs, deleteHarvestLog,
        addInventoryItem, updateInventoryItem, deleteInventoryItem, transferInventoryItem,
        addTransaction, deleteTransaction,
        addABWLogs, deleteABWLog,
        addApplicationLogs, deleteApplicationLog,
        updateSupervisorAssignments,
        getAllEventsForPond,
        getFinancialSummaryForSite,
        seedSampleData,
        resetAllData,
    };

    return (
        <DataContext.Provider value={value}>
            {children}
        </DataContext.Provider>
    );
};

export const useData = () => {
    const context = useContext(DataContext);
    if (context === undefined) {
        throw new Error('useData must be used within a DataProvider');
    }
    return context;
};
