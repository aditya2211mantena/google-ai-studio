
import { CultureType } from '../types';

export const ALL_SPECIES = [
    'Vannamei', 'Tiger', 'Scampi',
    'Rohu', 'Catla', 'Tilapia', 'Pangasius', 'Roopchand', 'Milk Fish', 'Grass Carp',
    'Seabass'
];

export const CULTURE_SPECIES_MAP: Record<CultureType, string[]> = {
    '🦐 Shrimp': ['Vannamei', 'Tiger', 'Scampi'],
    '🐟 Fresh Water Fish': ['Rohu', 'Catla', 'Tilapia', 'Pangasius', 'Roopchand', 'Milk Fish', 'Grass Carp'],
    '🌊 Marine Fish': ['Seabass'],
    '🌀 Mixed / Polyculture': ALL_SPECIES,
};

// NEW: Defines number of feeding slots per culture type
export const CULTURE_FEEDING_SLOTS: Record<CultureType, { count: number, labels: string[] }> = {
    '🦐 Shrimp': { count: 4, labels: ['Feed 1', 'Feed 2', 'Feed 3', 'Feed 4'] },
    '🐟 Fresh Water Fish': { count: 3, labels: ['Feed 1', 'Feed 2', 'Feed 3'] },
    '🌊 Marine Fish': { count: 3, labels: ['Feed 1', 'Feed 2', 'Feed 3'] },
    '🌀 Mixed / Polyculture': { count: 4, labels: ['Feed 1', 'Feed 2', 'Feed 3', 'Feed 4'] }
};