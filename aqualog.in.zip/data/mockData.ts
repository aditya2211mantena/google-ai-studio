
import type { Site, Pond, WaterQualityReading, FeedingEvent, MortalityLog, HarvestLog, InventoryItem, Transaction, ABWLog, ApplicationLog, User, CultureType } from '../types';
import { CULTURE_SPECIES_MAP } from './aquacultureData';

export const mockUsers: User[] = [
    { id: 1, name: 'Admin User', email: 'admin@aqualog.in', role: 'admin' },
    { id: 2, name: 'Supervisor User', email: 'supervisor@aqualog.in', role: 'supervisor' },
    { id: 3, name: 'Farmer User', email: 'farmer@aqualog.in', role: 'farmer' },
];

export const initialSites: Site[] = [
  { id: 1, name: 'Main Farm', location: 'Coastal Region', isDeleted: false, geolocation: { lat: 10.15, lng: 120.25 } },
  { id: 2, name: 'North Division', location: 'Northern Valley', isDeleted: false, geolocation: { lat: 11.1, lng: 121.2 } },
  { id: 3, name: 'Old Site', location: 'West Corner', isDeleted: true, geolocation: { lat: 9.9, lng: 119.8 } },
];

export const initialPonds: Pond[] = [
  { 
    id: 1, 
    name: 'Pond A1', 
    siteId: 1, 
    cultureType: '🐟 Fresh Water Fish', 
    stock: [{ species: 'Tilapia', count: 4995, initialABW: 5 }], 
    stockingDate: '2024-06-01', 
    status: 'Active',
    area: 1.2
  },
  { 
    id: 2, 
    name: 'Pond A2', 
    siteId: 1, 
    cultureType: '🦐 Shrimp', 
    stock: [{ species: 'Vannamei', count: 14950, initialABW: 0.5 }], 
    stockingDate: '2024-07-15', 
    status: 'Active',
    area: 0.8
  },
  { 
    id: 3, 
    name: 'Pond B1', 
    siteId: 2, 
    cultureType: '🌊 Marine Fish', 
    stock: [],
    stockingDate: '2024-03-20', 
    status: 'Harvested',
    area: 1.5
  },
  {
    id: 4,
    name: 'Poly Pond C1',
    siteId: 1,
    cultureType: '🌀 Mixed / Polyculture',
    stock: [
      { species: 'Catla', count: 900, initialABW: 10 },
      { species: 'Rohu', count: 2000, initialABW: 8 },
      { species: 'Vannamei', count: 10000, initialABW: 0.5 },
    ],
    stockingDate: '2024-05-10',
    status: 'Active',
    area: 2.0
  }
];

export const initialWaterReadings: WaterQualityReading[] = [
  { 
    id: 1, 
    pondId: 1,
    date: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0],
    pH: 8.0, salinity: 0.5, alkalinity: 150, co3: 15, hco3: 140, hardness: 180,
    ammonia_total: 0.2, nh3: 0.01, no2: 0.1, no3: 5, h2s: 0, co2: 10, do: 4.5,
    recordedById: 1, remarks: "All parameters normal."
  },
  { 
    id: 2,
    pondId: 2,
    date: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0],
    pH: 8.2, salinity: 25, alkalinity: 120, co3: 20, hco3: 110, hardness: 6000,
    ammonia_total: 0.5, nh3: 0.05, no2: 0.15, no3: 8, h2s: 0, co2: 8, do: 4.8,
    recordedById: 2, remarks: "Stable conditions."
  },
  {
    id: 3,
    pondId: 1,
    date: new Date(Date.now() - 86400000).toISOString().split('T')[0],
    pH: 7.8, salinity: 0.5, alkalinity: 140, co3: 12, hco3: 130, hardness: 170,
    ammonia_total: 0.8, nh3: 0.06, no2: 0.35, // no2 is high
    no3: 7, h2s: 0, co2: 12, do: 2.8, // do is low
    recordedById: 1, remarks: "DO dropped, started aerator. Nitrite is a bit high."
  },
   {
    id: 4,
    pondId: 2,
    date: new Date(Date.now() - 86400000).toISOString().split('T')[0],
    pH: 8.6, // pH is high
    salinity: 26, alkalinity: 110, co3: 25, hco3: 100, hardness: 6200,
    ammonia_total: 1.2, // TAN is high
    nh3: 0.15, // NH3 is high
    no2: 0.2, no3: 9, h2s: 0.01, co2: 7, do: 4.0,
    recordedById: 2, remarks: "High ammonia and pH, needs correction."
  },
];

export const initialInventory: InventoryItem[] = [
  { id: 1, name: 'Shrimp Starter Feed', category: 'Feed', quantity: 500, unit: 'kg', lowStockThreshold: 100, siteId: 1, applicableSpecies: ['Vannamei', 'Tiger', 'Scampi'], pricePerUnit: 1.5 },
  { id: 2, name: 'Fish Grower Feed', category: 'Feed', quantity: 780, unit: 'kg', lowStockThreshold: 150, siteId: 1, applicableSpecies: ['Tilapia', 'Rohu', 'Catla'], pricePerUnit: 1.2 },
  { id: 3, name: 'Probiotics', category: 'Feed Supplements', quantity: 19.9, unit: 'kg', lowStockThreshold: 5, siteId: 1, pricePerUnit: 50 },
  { id: 4, name: 'Zeolite', category: 'Pond Supplements', quantity: 140, unit: 'kg', lowStockThreshold: 50, siteId: 1, pricePerUnit: 15 },
  { id: 5, name: 'Vannamei Feed', category: 'Feed', quantity: 289.5, unit: 'kg', lowStockThreshold: 100, siteId: 1, applicableSpecies: ['Vannamei'], pricePerUnit: 1.8 },
  { id: 6, name: 'Generic Fish Feed', category: 'Feed', quantity: 250, unit: 'kg', lowStockThreshold: 100, siteId: 2, pricePerUnit: 1.0 },
  { id: 7, name: 'Vitamin Mix', category: 'Feed Supplements', quantity: 10, unit: 'kg', lowStockThreshold: 5, siteId: 1, pricePerUnit: 100 },
  { id: 8, name: 'Minerals', category: 'Pond Supplements', quantity: 29.8, unit: 'kg', lowStockThreshold: 10, siteId: 1, pricePerUnit: 20 },
];

export const initialFeedingEvents: FeedingEvent[] = [
  { 
    id: 1, 
    pondId: 1,
    feedSlot: 1,
    inventoryFeedId: 2,
    quantity: 10, 
    supplements: [ { inventoryItemId: 3, quantityUsed: 0.1 } ],
    time: new Date(Date.now() - 86400000 * 2).toISOString(), 
    recordedById: 1 
  },
  { 
    id: 2, 
    pondId: 2,
    feedSlot: 1,
    inventoryFeedId: 5,
    quantity: 5, 
    supplements: [],
    time: new Date(Date.now() - 86400000 * 2).toISOString(), 
    recordedById: 2
  },
  { 
    id: 3, 
    pondId: 2,
    feedSlot: 2,
    inventoryFeedId: 5,
    quantity: 5.5, 
    supplements: [ { inventoryItemId: 7, quantityUsed: 0.05 } ],
    time: new Date(Date.now() - 86400000 * 2 + 4 * 3600000).toISOString(),
    recordedById: 2
  },
   { 
    id: 4, 
    pondId: 1,
    feedSlot: 1,
    inventoryFeedId: 2,
    quantity: 10.2, 
    supplements: [ { inventoryItemId: 3, quantityUsed: 0.1 } ],
    time: new Date(Date.now() - 86400000).toISOString(), 
    recordedById: 1 
  },
   { 
    id: 5, 
    pondId: 2,
    feedSlot: 1,
    inventoryFeedId: 5,
    quantity: 5.2, 
    supplements: [],
    time: new Date(Date.now() - 86400000).toISOString(), 
    recordedById: 2
  },
    { 
    id: 6, 
    pondId: 2,
    feedSlot: 2,
    inventoryFeedId: 5,
    quantity: 5.8, 
    supplements: [ { inventoryItemId: 7, quantityUsed: 0.05 } ],
    time: new Date(Date.now() - 86400000 + 4 * 3600000).toISOString(),
    recordedById: 2
  },
];


export const initialMortalityLogs: MortalityLog[] = [
  { 
    id: 1, 
    pondId: 1, 
    speciesName: 'Tilapia',
    previousStock: 5000,
    mortality: 5, 
    newStock: 4995,
    abwAtEntry: 0.025, // 25g
    newBiomass: 124.875,
    remarks: 'Natural', 
    date: new Date(Date.now() - 86400000 * 3).toISOString(),
    recordedById: 1 
  },
  { 
    id: 2, 
    pondId: 2,
    speciesName: 'Vannamei',
    previousStock: 15000,
    mortality: 50,
    newStock: 14950,
    abwAtEntry: 0.003, // 3g
    newBiomass: 44.85,
    remarks: 'Oxygen drop', 
    date: new Date(Date.now() - 86400000 * 2).toISOString(),
    recordedById: 2 
  },
];

export const initialHarvestLogs: HarvestLog[] = [
    { 
        id: 1, 
        pondId: 4, 
        speciesName: 'Catla',
        harvestType: 'Partial',
        numberHarvested: 100,
        totalWeight: 120,
        abw: 1.2,
        costPerKg: 150,
        value: 18000,
        remarks: 'Test partial harvest',
        date: new Date(Date.now() - 86400000 * 5).toISOString(),
        recordedById: 2,
        transactionId: 101,
    }
];

export const initialTransactions: Transaction[] = [
  { id: 1, type: 'expense', description: 'Purchase of PL for Pond A2', amount: 500, date: '2024-07-15', siteId: 1 },
  { id: 2, type: 'expense', description: 'Purchase of fry for Pond A1', amount: 300, date: '2024-06-01', siteId: 1 },
  { id: 3, type: 'expense', description: 'Monthly electricity bill', amount: 250, date: '2024-07-01', siteId: 1 },
  { id: 4, type: 'income', description: 'Harvest sale from Pond B1', amount: 10200, date: '2024-07-10', siteId: 2 },
  { id: 5, type: 'expense', description: 'Feed purchase', amount: 2500, date: '2024-07-05', siteId: 1 },
  { id: 6, type: 'expense', description: 'Labor salary', amount: 1500, date: '2024-07-01', siteId: 1 },
  { id: 101, type: 'income', description: 'Partial harvest of Catla from Poly Pond C1', amount: 18000, date: new Date(Date.now() - 86400000 * 5).toISOString(), siteId: 1 },
  { id: 201, type: 'expense', description: 'Application of Zeolite in Pond A1', amount: 150, date: new Date(Date.now() - 86400000 * 4).toISOString(), siteId: 1 },
];

export const initialABWLogs: ABWLog[] = [
    { 
      id: 1, pondId: 1, speciesName: 'Tilapia', samplingDate: new Date(Date.now() - 86400000 * 14).toISOString(),
      cultureType: 'Fish', samplingNumber: 50, samplingWeight: 1250,
      calculatedAbw: 25, abwGrowthDelta: 20, fcrThisPeriod: undefined, fcrCumulative: 1.2,
      recordedById: 1
    },
    { 
      id: 2, pondId: 1, speciesName: 'Tilapia', samplingDate: new Date(Date.now() - 86400000 * 7).toISOString(),
      cultureType: 'Fish', samplingNumber: 50, samplingWeight: 1750,
      calculatedAbw: 35, abwGrowthDelta: 10, fcrThisPeriod: 1.42, fcrCumulative: 1.3,
      recordedById: 1 
    },
    { 
      id: 3, pondId: 2, speciesName: 'Vannamei', samplingDate: new Date(Date.now() - 86400000 * 10).toISOString(),
      cultureType: 'Shrimp', samplingNumber: 100, samplingWeight: 300,
      calculatedAbw: 3.0, calculatedCount: 333.3, abwGrowthDelta: 2.5, countGrowthDelta: -1666.7, fcrThisPeriod: undefined, fcrCumulative: 1.1,
      recordedById: 2 
    },
     { 
      id: 4, pondId: 2, speciesName: 'Vannamei', samplingDate: new Date(Date.now() - 86400000 * 3).toISOString(),
      cultureType: 'Shrimp', samplingNumber: 100, samplingWeight: 520,
      calculatedAbw: 5.2, calculatedCount: 192.3, abwGrowthDelta: 2.2, countGrowthDelta: -141, fcrThisPeriod: 1.55, fcrCumulative: 1.25,
      recordedById: 2 
    },
];

export const initialApplicationLogs: ApplicationLog[] = [
    { 
        id: 1, 
        pondId: 1, 
        siteId: 1,
        inventoryItemId: 4,
        productName: 'Zeolite',
        category: 'Pond Supplements',
        unit: 'kg',
        quantityUsed: 10,
        purpose: 'Ammonia control',
        remarks: 'Bottom cleaning',
        recordedById: 2,
        date: new Date(Date.now() - 86400000 * 4).toISOString(),
        transactionId: 201
    },
];

export const initialSupervisorAssignments: { [userId: number]: number[] } = {
    2: [1]
};

// --- DATA GENERATION HELPERS ---

const randomFromArray = <T>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

export const generateRandomPonds = (count: number, existingSites: Site[]): Pond[] => {
    const newPonds: Pond[] = [];
    const activeSites = existingSites.filter(s => !s.isDeleted);
    if (activeSites.length === 0) return [];

    for (let i = 0; i < count; i++) {
        const site = randomFromArray(activeSites);
        const cultureType = randomFromArray<CultureType>(['🦐 Shrimp', '🐟 Fresh Water Fish']);
        const species = randomFromArray(CULTURE_SPECIES_MAP[cultureType]);
        newPonds.push({
            id: Date.now() + i,
            name: `Sample Pond ${String.fromCharCode(65 + Math.floor(Math.random() * 26))}${Math.floor(Math.random() * 10)}`,
            siteId: site.id,
            cultureType,
            stock: [{ species, count: Math.floor(Math.random() * 10000) + 1000, initialABW: Math.random() * 10 }],
            stockingDate: new Date(Date.now() - Math.random() * 90 * 24 * 3600 * 1000).toISOString().split('T')[0],
            status: 'Active',
            area: Math.round((Math.random() * 2 + 0.5) * 10) / 10,
        });
    }
    return newPonds;
};

export const generateRandomLogs = (count: number, activePonds: Pond[], siteInventory: InventoryItem[]) => {
    const newWaterReadings: WaterQualityReading[] = [];
    const newFeedingEvents: FeedingEvent[] = [];
    const newMortalityLogs: MortalityLog[] = [];

    for (let i = 0; i < count; i++) {
        const pond = randomFromArray(activePonds);
        const logType = randomFromArray(['water', 'feed', 'mortality']);
        const date = new Date(Date.now() - Math.random() * 60 * 24 * 3600 * 1000);
        const recordedById = randomFromArray([1, 2, 3]);

        if (logType === 'water') {
            newWaterReadings.push({
                id: Date.now() + i,
                pondId: pond.id,
                date: date.toISOString().split('T')[0],
                pH: 7.0 + Math.random() * 2, // 7.0-9.0
                salinity: 10 + Math.random() * 20,
                alkalinity: 80 + Math.random() * 120,
                do: 2.5 + Math.random() * 4,
                nh3: Math.random() * 0.2,
                no2: Math.random() * 0.4,
                h2s: Math.random() * 0.1,
                recordedById,
            });
        } else if (logType === 'mortality' && pond.stock.length > 0) {
            const stockItem = randomFromArray(pond.stock);
            const mortalityCount = Math.floor(Math.random() * 100);
            newMortalityLogs.push({
                id: Date.now() + i,
                pondId: pond.id,
                date: date.toISOString(),
                speciesName: stockItem.species,
                mortality: mortalityCount,
                previousStock: stockItem.count + mortalityCount, // Approximation
                newStock: stockItem.count,
                abwAtEntry: 0.05, // 50g placeholder
                newBiomass: stockItem.count * 0.05,
                remarks: 'Random observation',
                recordedById,
            });
        } else if (logType === 'feed') {
            const relevantFeeds = siteInventory.filter(item => item.category === 'Feed' && item.siteId === pond.siteId);
            if (relevantFeeds.length > 0) {
                const feedItem = randomFromArray(relevantFeeds);
                newFeedingEvents.push({
                    id: Date.now() + i,
                    pondId: pond.id,
                    feedSlot: Math.floor(Math.random() * 4) + 1,
                    inventoryFeedId: feedItem.id,
                    quantity: Math.floor(Math.random() * 20) + 5,
                    supplements: [],
                    time: date.toISOString(),
                    recordedById,
                });
            }
        }
    }
    return { newWaterReadings, newFeedingEvents, newMortalityLogs };
};
