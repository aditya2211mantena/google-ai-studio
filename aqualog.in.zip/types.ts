
export type UserRole = 'admin' | 'supervisor' | 'farmer';

export interface User {
  id: number;
  name: string;
  email: string;
  role: UserRole;
}

export interface Site {
  id: number;
  name: string;
  location: string;
  isDeleted: boolean;
  geolocation: { lat: number; lng: number };
}

export type CultureType = '🦐 Shrimp' | '🐟 Fresh Water Fish' | '🌊 Marine Fish' | '🌀 Mixed / Polyculture';
export type PondStatus = 'Active' | 'Harvested';

export interface Pond {
  id: number;
  name:string;
  siteId: number;
  cultureType: CultureType;
  stock: {
    species: string;
    count: number;
    initialABW: number; // in grams
  }[];
  stockingDate: string;
  status: PondStatus;
  area?: number; // in acres
}

export interface WaterQualityReading {
    id: number;
    pondId: number;
    date: string;
    recordedById?: number;
    remarks?: string;

    // Chemical Analysis
    pH?: number;
    salinity?: number; // ppt
    alkalinity?: number; // mg/L
    co3?: number; // mg/L Carbonate
    hco3?: number; // mg/L Bicarbonate
    hardness?: number; // mg/L

    // Toxic Gases
    ammonia_total?: number; // ppm (TAN)
    nh3?: number; // ppm (Un-ionized ammonia)
    no2?: number; // ppm (Nitrite)
    no3?: number; // ppm (Nitrate)
    h2s?: number; // ppm (Hydrogen Sulfide)
    co2?: number; // ppm (Carbon Dioxide)
    do?: number; // mg/L (Dissolved Oxygen)
}

export interface FeedingEvent {
  id: number;
  pondId: number;
  feedSlot: number;
  inventoryFeedId: number;
  quantity: number;
  supplements: {
    inventoryItemId: number;
    quantityUsed: number;
  }[];
  time: string;
  recordedById: number;
}


export interface MortalityLog {
    id: number;
    pondId: number;
    speciesName: string;
    previousStock: number;
    mortality: number;
    newStock: number;
    abwAtEntry: number; // in kg
    newBiomass: number; // kg
    remarks?: string;
    date: string;
    recordedById?: number;
}

export type HarvestType = 'Partial' | 'Full';

export interface HarvestLog {
    id: number;
    pondId: number;
    speciesName: string;
    harvestType: HarvestType;
    numberHarvested: number;
    totalWeight: number; // kg
    abw: number; // kg
    costPerKg?: number;
    value?: number;
    remarks?: string;
    date: string;
    recordedById?: number;
    transactionId?: number;
}


export interface InventoryItem {
    id: number;
    name: string;
    category: 'Feed' | 'Feed Supplements' | 'Pond Supplements';
    quantity: number;
    unit: string;
    lowStockThreshold: number;
    siteId: number;
    applicableSpecies?: string[];
    pricePerUnit?: number;
}

export interface Transaction {
    id: number;
    type: 'income' | 'expense';
    description: string;
    amount: number;
    date: string;
    siteId: number;
}

export interface ABWLog {
    id: number;
    pondId: number;
    speciesName: string;
    samplingDate: string;
    cultureType: 'Shrimp' | 'Fish';
    samplingNumber: number;
    samplingWeight: number; // in grams
    calculatedAbw: number; // in grams
    calculatedCount?: number; // pcs/kg, shrimp only
    abwGrowthDelta: number; // in grams
    countGrowthDelta?: number;
    fcrThisPeriod?: number;
    fcrCumulative?: number;
    recordedById?: number;
}

export interface ApplicationLog {
    id: number;
    pondId: number;
    siteId: number;
    inventoryItemId: number;
    productName: string;
    category: 'Pond Supplements' | 'Feed Supplements';
    unit: string;
    quantityUsed: number;
    purpose?: string;
    remarks?: string;
    recordedById: number;
    date: string;
    transactionId?: number;
}

// Union type for the unified timeline
export type PondEvent = 
    | ({ type: 'feed' } & FeedingEvent)
    | ({ type: 'water' } & WaterQualityReading)
    | ({ type: 'mortality' } & MortalityLog)
    | ({ type: 'harvest' } & HarvestLog)
    | ({ type: 'abw' } & ABWLog)
    | ({ type: 'application' } & ApplicationLog);
